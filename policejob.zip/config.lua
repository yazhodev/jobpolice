Config = {}

Config = {
    ColorMenuR = 61,
    ColorMenuG = 120,
    ColorMenuB = 242,
    ColorMenuA = 255,
    PermMenuBoss = 7, 
    PermAmu = 1, 
    PermCam = 1,
    PermCasier = 1,
    PermCoffre = 1, 
    PermGarage = 1, 
    PermGarageHeli = 1,
    PermGarageBateau = 1,
    PermGestPermis = 1, 
    PermBDD = 1, 
    PermVestiaire = 1, 
    PermRmvCar = 1,
    PermRecherche = 1,
    PermObjet = 1, 
    PermChien = 1, 
    PermRadar = 1,
    PermRetrait = 1,
    PermDepot = 1,
    PermCamHelico = 1,
    armesEnItems = false,
    ESextendedLegacy = true,
    MenotteItem = false,
    Alert = true,
    ReventeSaisies = true,
    GarageCar = true,
    GarageHeli = true,
    GarageBateau = true,
    deleteContent = true,
    JobName = "police",
    SocietyName = "society_police",
    logs = {
        Armurerie = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        Boss = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        Camera = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        Casier = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        CoffreObjets = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        CoffreArmes = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        AcceuilPolice = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        GestionPermis = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        CasierPolice = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        GavPolice = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        PriseFinService = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        AvisDeRecherche = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        Objets = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        FactureAmende = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",
        Fouille = "https://discord.com/api/webhooks/1328022533575807101/CAN-Zc2VkeMlZzMY58L8HInMsZgtgK83eLVNkN5m6FJ6fSr0jfz8UIC8384cFS-ISMBb",

    },
    armurerie = {
        {nom = "Pistolet", arme = "weapon_pistol", minimum_grade = 0},
        {nom = "Fusil à pompe", arme = "weapon_pumpshotgun_mk2", minimum_grade = 0},
        {nom = "M4", arme = "weapon_carbinerifle", minimum_grade = 0}
    },
    spawn = {
        spawnvoiture = {position = {x = 452.38, y = -989.59, z = 25.7, h = 1.07}},
        spawnheli = {position = {x = 448.69, y = -981.65, z = 43.69, h = 87.916}},
        spawnbato = {position = {x = 452.38, y = -989.59, z = 25.7, h = 1.07}}
    },
}

Config.pos = {
    armurerie = {position = {x = 484.3157, y = -1002.08, z = 25.734}},
    boss = {position = {x = 471.7821, y = -1005.62, z = 30.693}}, 
    cameraview = {position = {x = 438.7171, y = -992.259, z = 30.689}},
    casierjudiciaire = {position = {x = 454.1030, y = -984.565, z = 30.689}},
    coffre = {position = {x = 474.3954, y = -1006.79, z = 34.217}}, 
    garagevoiture = {position = {x = 452.8708, y = -973.029, z = 25.788}},
    garageheli = {position = {x = 449.2021, y = -981.142, z = 43.691, h = 28.64}},
    garagebateau = {position = {x = -800.544, y = -1494.72, z = 1.5952, h = 199.23}},
    menuPermisInfo = {position = {x = 454.2638, y = -987.870, z = 30.689}},
    plainterdv = {position = {x = 441.5216, y = -982.809, z = 30.689}},
    vestiaire = {position = {x = 473.5384, y = -988.085, z = 25.734}},
    tenueGav = {position = {x = 442.8988, y = -996.033, z = 34.187}},
    menuVerifBdd = {position = {x = 450.1473, y = -984.632, z = 30.689}},
    modifcar = {position = {x = 459.4107, y = -978.898, z = 25.729}}
}

police = {
    clothes = {
        specials = {
            [0] = {
                label = "Reprendre Sa Tenue",
                minimum_grade = 0,
                variations = {male = {}, female = {}},
                onEquip = function()
                    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                        TriggerEvent('skinchanger:loadSkin', skin)
                    end)
                    SetPedArmour(PlayerPedId(), 0)
                end
            },
            [1] = {
                label = "Tenue de Cadet",
                minimum_grade = 0,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            },
            [2] = {
                label = "Tenue d'Officier",
                minimum_grade = 1,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            },
            [3] = {
                label = "Tenue de Sergent",
                minimum_grade = 2,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            },
            [4] = {
                label = "Tenue de Sergent-Formmateur",
                minimum_grade = 3,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            },
            [5] = {
                label = "Tenue de Sergent-Chef",
                minimum_grade = 4,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            },
            [6] = {
                label = "Tenue de Lieutenant",
                minimum_grade = 5,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            },
            [7] = {
                label = "Tenue de Capitaine",
                minimum_grade = 6,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            },
            [8] = {
                label = "Tenue de Commandant",
                minimum_grade = 7,
                variations = {
                    male = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 39, ['tshirt_2'] = 0,
                        ['torso_1'] = 55, ['torso_2'] = 0,
                        ['arms'] = 30,
                        ['pants_1'] = 46, ['pants_2'] = 0,
                        ['shoes_1'] =25, ['shoes_2'] = 0,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    },
                    female = {
                        ['bags_1'] = 0, ['bags_2'] = 0,
                        ['tshirt_1'] = 15,['tshirt_2'] = 2,
                        ['torso_1'] = 65, ['torso_2'] = 2,
                        ['arms'] = 36, ['arms_2'] = 0,
                        ['pants_1'] = 38, ['pants_2'] = 2,
                        ['shoes_1'] = 12, ['shoes_2'] = 6,
                        ['mask_1'] = 0, ['mask_2'] = 0,
                        ['bproof_1'] = 0,
                        ['chain_1'] = 0,
                        ['helmet_1'] = -1, ['helmet_2'] = 0,
                    }
                },
                onEquip = function()  
                end
            }
        },
        grades = {
            [0] = {
                label = "Mettre un Gilet Par-Balle",
                minimum_grade = 0,
                variations = {
                male = {
                    ['bproof_1'] = 1,
                },
                female = {
                    ['bproof_1'] = 1,
                }
            },
            onEquip = function()
            end
        },
		[1] = {
			label = "Enlever le Gilet Par-Balle",
			minimum_grade = 0,
			variations = {
			male = {
				['bproof_1'] = 0,
			},
			female = {
				['bproof_1'] = 0,
			}
		},
		onEquip = function()
		end
	},
    }
},
	vehicles = {                                                         
        car = {                                                         
            {category = "Liste des Véhicules"},                           
            {model = "police", label = "Véhicule de Patrouille n°1", minimum_grade = 0},
            {model = "police2", label = "Véhicule de Patrouille n°2", minimum_grade = 0}, 
            {model = "police3", label = "Véhicule de Patrouille n°3", minimum_grade = 0},  
            {model = "police4", label = "Véhicule de Patrouille n°4", minimum_grade = 0},  
            {model = "policet", label = "Fourgon de Transport", minimum_grade = 0},
            {model = "riot", label = "Véhicule [BLINDÉ]", minimum_grade = 0},
        },
        helico = {
            {category = "Liste de(s) Hélicoptère(s)"},
            {model = "polmav", label = "Hélico du LSPD", minimum_grade = 0}
        },
        bateaux = {
            {category = "Liste de(s) Bateau(x)"},
            {model = "predator", label = "Predator", minimum_grade = 0},
            {model = "seashark", label = "Jet-Ski", minimum_grade = 0}
        }
    }
}