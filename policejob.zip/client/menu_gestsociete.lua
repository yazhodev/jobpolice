ESX = nil 

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end

    ESX.PlayerData = ESX.GetPlayerData()
end)

listegens1 = {}
salairee = {}

local PlayerData = {}
local societypolicemoney = nil

local Action = {
    Attribuer = {'PPA','Permis', "Code"}, Liste = 1,
	Destituer = {'PPA','Permis', "Code"}, Listee = 1,
}

local function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end

local function starts(String, Start)
    return string.sub(String, 1, string.len(Start)) == Start
end

local filterArray = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" }
local filter = 1

function BossPolice()
	local main = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
	local societygestion = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	local main2 = RageUI.CreateSubMenu(societygestion, "POLICE", "MENU D'INTERACTIONS")
	local salairegestion = RageUI.CreateSubMenu(societygestion, "POLICE", "MENU D'INTERACTIONS")
	local casiergestion = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	main:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	main2:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	salairegestion:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	societygestion:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	casiergestion:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)

	RageUI.Visible(main, not RageUI.Visible(main))
			while main do
				Citizen.Wait(0)
					RageUI.IsVisible(main, true, true, true, function()
				if societypolicemoney ~= nil then
					RageUI.Button("Capital du Poste de Police ~m~("..Config.SocietyName..")~s~", nil, {}, true, {
						onSelected = function()
							RefreshpoliceMoney()
						end
					})
					RageUI.Separator("~b~"..societypolicemoney.."$")
				end
				RageUI.Button("Gestion de la Société", nil, {RightLabel = "→→"}, true, {
					onSelected = function()
						RefreshpoliceMoney()
					end
				}, societygestion)
				RageUI.Button("Gestion Casiers", nil, {RightLabel = "→→"}, true, {}, casiergestion)
				RageUI.List("Attribuer une License", Action.Attribuer, Action.Liste, nil, {RightLabel = ""}, not cooldown, function(Hovered, Active, Selected, Index)
					if (Selected) then 
						if Index == 1 then
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('add:addlic', GetPlayerServerId(closestPlayer), "ppa")
								RageUI.Popup({message = "Le joueur a bien reçu sont ppa"})
							else
								RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
							end 
						elseif Index == 2 then
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
									TriggerServerEvent('add:addlic', GetPlayerServerId(closestPlayer), "drive")
								RageUI.Popup({message = "Le joueur a bien reçu sont permis"})
							else
								RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
							end 
						elseif Index == 3 then
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
									TriggerServerEvent('add:addlic', GetPlayerServerId(closestPlayer), "code")
								RageUI.Popup({message = "Le joueur a bien reçu sont permis"})
							else
								RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
							end 	
						end
						
					end
					Action.Liste = Index;              
				end)
				RageUI.List("Destituer une License", Action.Destituer, Action.Listee, nil, {RightLabel = ""}, not cooldown, function(Hovered, Active, Selected, Index)
					if (Selected) then 
						if Index == 1 then
								local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
								if closestPlayer ~= -1 and closestDistance <= 3.0 then
									TriggerServerEvent('sup:addlic', GetPlayerServerId(closestPlayer), "ppa")
							else
								RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
							end 
						elseif Index == 2 then
								local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
								if closestPlayer ~= -1 and closestDistance <= 3.0 then
									TriggerServerEvent('sup:addlic', GetPlayerServerId(closestPlayer), "drive")
									RageUI.Popup({message = "Le joueur a bien reçu sont permis"})
							else
								RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
							end 
						elseif Index == 3 then
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('sup:addlic', GetPlayerServerId(closestPlayer), "code")
								RageUI.Popup({message = "Le joueur a bien reçu sont permis"})
						else
							RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
						end 
						end
						
					end
					Action.Listee = Index;              
				end)
				RageUI.Line()
				RageUI.Button("Faire une Annonce", nil, {RightLabel = "→"}, true, {
					onSelected = function()
						local msg = KeyboardInput("Annonce à tout le monde", "", 10)
						ExecuteCommand("lspd "..msg)
						
					end
					})
			end, function()
			end)

				RageUI.IsVisible(societygestion, true, true, true, function()
					if societypolicemoney ~= nil then
						RageUI.Separator("Capital restant - ~b~"..societypolicemoney.."$")
					end
					RageUI.Button("Retirer de l'argent",nil, {RightLabel = "→"}, true, {
						onSelected = function()
							local amount = KeyboardInput("Montant", "", 10)
							amount = tonumber(amount)
							if amount == nil then
								RageUI.Popup({message = "~r~Montant Invalide."})
							else
								TriggerServerEvent('esx_society:withdrawMoney', 'police', amount)
								RefreshpoliceMoney()
							end
						end
					})
					RageUI.Button("Déposer de l'argent",nil, {RightLabel = "→"}, true, {
						onSelected = function()
							local amount = KeyboardInput("Montant", "", 10)
							amount = tonumber(amount)
							if amount == nil then
								RageUI.Popup({message = "~r~Montant Invalide."})
							else
								TriggerServerEvent('esx_society:depositMoney', 'police', amount)
								RefreshpoliceMoney()
							end
						end
					})
					RageUI.Line()
					RageUI.Separator("Actions sur Autrui")
					RageUI.Button("Recruter un Joueur ~m~(le plus proche)~s~", nil, {RightLabel = "→"}, true, {
						onSelected = function()
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('patron:recruter', "police", false, GetPlayerServerId(closestPlayer))
							else
								RageUI.Popup({message = "~r~Aucun joueur à proximité."})
							end 
						end
						})
						RageUI.Button("Promouvoir un Joueur ~m~(le plus proche)~s~", nil, {RightLabel = "→"}, true, {
						onSelected = function()
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('patron:promouvoir', "police", false, GetPlayerServerId(closestPlayer))
							else
								RageUI.Popup({message = "~r~Aucun joueur à proximité."})
							end 	
						end
						})
						RageUI.Button("Rétrograder un Joueur ~m~(le plus proche)~s~", nil, {RightLabel = "→"}, true, {
						onSelected = function()  
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('patron:descendre', "police", false, GetPlayerServerId(closestPlayer))
							else
								RageUI.Popup({message = "~r~Aucun joueur à proximité."})
							end 	
						end
						})
						RageUI.Button("Virer un Joueur ~m~(le plus proche)~s~", nil, {RightLabel = "→"}, true, {
						onSelected = function()
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('patron:virer', "police", false, GetPlayerServerId(closestPlayer))
							else
								RageUI.Popup({message = "~r~Aucun joueur à proximité."})
							end 							
						end
						})
						RageUI.Line()
						RageUI.Separator("Gestions")
					RageUI.Button("Gestion Salaires", nil, {RightLabel = "→"}, true, {}, salairegestion)  

				end, function()
				end)

				RageUI.IsVisible(main2, true, true, true, function()
					RageUI.List("Filtre :", filterArray, filter, nil, {}, true, function(_, _, _, i)
						filter = i
					end)
					if listegens1[i] == nil then
						RageUI.Separator("~r~Aucun employé")
					else
					for i = 1, #listegens1, 1 do
						if starts(listegens1[i].nom:lower(), filterArray[filter]:lower()) then
							RageUI.Button(listegens1[i].prenom.." "..listegens1[i].nom, nil, {RightLabel = 'Virer'}, true, {
								onSelected = function()
									TriggerServerEvent('yazho:virersql', listegens1[i].steam)
									RageUI.Popup({message = "La personne a été viré"})
									RageUI.CloseAll()
								end
							})
					else 
						RageUI.Separator("~r~Aucun nom d'employé commençant par "..filterArray[filter])
					end
				end
			end
				end, function()
				end)

				RageUI.IsVisible(casiergestion, true, true, true, function()
					RageUI.Separator("Actions sur Autrui")
					RageUI.Button("Attribuer un casier LSPD", nil, {RightLabel = "→"}, true, {
						onSelected = function()   
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('yazho:addCasier', GetPlayerServerId(closestPlayer))
							else
								RageUI.Popup({message = "~r~Aucun joueur à proximité."})
							end
						end
					})
					RageUI.Button("Destituer le casier LSPD", nil, {RightLabel = "→"}, true, {
						onSelected = function()   
							local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
							if closestPlayer ~= -1 and closestDistance <= 3.0 then
								TriggerServerEvent('yazho:removeCasier', GetPlayerServerId(closestPlayer))
							else
								RageUI.Popup({message = "~r~Aucun joueur à proximité."})
							end
						end
					})
					RageUI.Line()
					RageUI.Separator("Actions pour Soi")
					RageUI.Button("Attribuer un casier LSPD (Moi)", nil, {RightLabel = "→"}, true, {
						onSelected = function()   
							TriggerServerEvent('yazho:addCasier', GetPlayerServerId(PlayerId()))
						end
					})
					RageUI.Button("Destituer le casier LSPD (Moi)", nil, {RightLabel = "→"}, true, {
						onSelected = function()   
							TriggerServerEvent('yazho:removeCasier', GetPlayerServerId(PlayerId()))
						end
					})
				end, function()
				end)

				RageUI.IsVisible(salairegestion, true, true, true, function()
				for i = 1, #salairee, 1 do
					RageUI.Button(salairee[i].nom.." / ~b~"..salairee[i].salaire.."$", nil, {RightLabel = 'CHANGER'}, true, {
							onSelected = function()
								local montant = KeyboardInput('Veuillez choisir le montant', '', 8)
								montant = tonumber(montant)
								if not montant then
								RageUI.Popup({message = "~r~Quantité Invalide."})
								else
								if montant > 10000 then
								RageUI.Popup({message = "Le salaire ne peut pas être supérieur à 10000$"})
								else         
								TriggerServerEvent('yazho:changersalaire', salairee[i].id, montant)
								RageUI.Popup({message = "Changement du salaire effectué."})
								RageUI.CloseAll()
								end
							end
						end
					})
				end
		end, function()
		end)

		if not RageUI.Visible(main) and not RageUI.Visible(main2) and not RageUI.Visible(salairegestion)  and not RageUI.Visible(societygestion) and not RageUI.Visible(casiergestion) then
			main = RMenu:DeleteType("Actions Patron", true)
		end
	end
end

function RefreshpoliceMoney()
    if ESX.PlayerData.job ~= nil and ESX.PlayerData.job.grade_name == 'boss' then
        ESX.TriggerServerCallback('yazho:getSocietyMoney', function(money)
            UpdateSocietypoliceMoney(money)
        end, ESX.PlayerData.job.name)
		ESX.TriggerServerCallback('five_patron:listegensjob1', function(liste)
			listegens1 = liste
		end, ESX.PlayerData.job.name)
		ESX.TriggerServerCallback('five_patron:listesalaire', function(liste)
			salairee = liste
		end, ESX.PlayerData.job.name)
    end
end

function UpdateSocietypoliceMoney(money)
    societypolicemoney = ESX.Math.GroupDigits(money)
end
  
Citizen.CreateThread(function()
	  while true do
		  local Timer = 800
		  if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermMenuBoss then
		  local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
		  local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.boss.position.x, Config.pos.boss.position.y, Config.pos.boss.position.z)
		  if dist3 <= 5.0 then 
			  Timer = 0
			  DrawMarker(23, Config.pos.boss.position.x, Config.pos.boss.position.y, Config.pos.boss.position.z-0.98, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
			end
			  if dist3 <= 3.0 then
				  Timer = 0   
				  		ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder à la gestion de la société.")
						if IsControlJustPressed(1,51) then
						RefreshpoliceMoney()
						BossPolice()
					  end   
				  end
			  end 
		  Citizen.Wait(Timer)
	  end
end)