ESX = nil
local playersInGAV = {}

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	ESX.PlayerData.job = job  
	
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	local blipbateau = AddBlipForCoord(-800.544, -1494.72, 1.5952) 
	SetBlipDisplay(blipbateau, 5)
	SetBlipSprite(blipbateau, 755)
	SetBlipColour(blipbateau, 3)
	SetBlipAsShortRange(blipbateau, true)
	BeginTextCommandSetBlipName('STRING')
	AddTextComponentString("L.S.P.D")
	EndTextCommandSetBlipName(blipbateau)
end)

Citizen.CreateThread(function()
	local blippolicejob = AddBlipForCoord(441.5086, -982.572, 30.689)
	SetBlipSprite(blippolicejob, 60)
	SetBlipColour(blippolicejob, 3)
	SetBlipAsShortRange(blippolicejob, true)
	BeginTextCommandSetBlipName('STRING')
	AddTextComponentString("Poste de Police")
	EndTextCommandSetBlipName(blippolicejob)
end)

object = {}
OtherItems = {}
local inventaire = false
local status = true

local function LoadAnimDict(dictname)
	if not HasAnimDictLoaded(dictname) then
		RequestAnimDict(dictname) 
		while not HasAnimDictLoaded(dictname) do 
			Citizen.Wait(1)
		end
	end
end

loadDict = function(dict)
    while not HasAnimDictLoaded(dict) do Wait(0) RequestAnimDict(dict) end
end

local ped = PlayerPedId()
local vehicle = GetVehiclePedIsIn( ped, false )
local blip = nil
local policeDog = false
local PlayerData = {}
local currentTask = {}
local closestDistance, closestEntity = -1, nil
local Items = {}
local Armes = {}
local ArgentSale = {}
local IsHandcuffed, DragStatus = false, {}
DragStatus.IsDragged          = false

local function MarquerJoueur()
	local ped = GetPlayerPed(ESX.Game.GetClosestPlayer())
	local pos = GetEntityCoords(ped)
	local target, distance = ESX.Game.GetClosestPlayer()
	if distance <= 4.0 then
		DrawMarker(42, pos.x, pos.y, pos.z+1.3, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
	end
end

local function getPlayerInv(player)
Items = {}
Armes = {}
ArgentSale = {}

ESX.TriggerServerCallback('yazhopolice:getOtherPlayerData', function(data)
	for i=1, #data.accounts, 1 do
		if data.accounts[i].name == 'black_money' and data.accounts[i].money > 0 then
			table.insert(ArgentSale, {
				label    = ESX.Math.Round(data.accounts[i].money),
				value    = 'black_money',
				itemType = 'item_account',
				amount   = data.accounts[i].money
			})

			break
		end
	end
	for i=1, #data.weapons, 1 do
		table.insert(Armes, {
			label    = ESX.GetWeaponLabel(data.weapons[i].name),
			value    = data.weapons[i].name,
			right    = data.weapons[i].ammo,
			itemType = 'item_weapon',
			amount   = data.weapons[i].ammo
		})
	end
	for i=1, #data.inventory, 1 do
		if data.inventory[i].count > 0 then
			table.insert(Items, {
				label    = data.inventory[i].label,
				right    = data.inventory[i].count,
				value    = data.inventory[i].name,
				itemType = 'item_standard',
				amount   = data.inventory[i].count
			})
		end
	end
end, GetPlayerServerId(player))
end

function getInformations(player)
	ESX.TriggerServerCallback('yazhopolice:getOtherPlayerData', function(data)
		identityStats = data
	end, GetPlayerServerId(player))
end

local function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end

local current = "police"
local dangerosityTable = {[1] = "Coopératif",[2] = "Dangereux",[3] = "Dangereux et armé",[4] = "Terroriste"}
lspdADRDangerosities = {"Coopératif","Dangereux","Dangereux et armé","Terroriste"}
lspdADRBuilder = {dangerosity = 1}
lspdADRData = nil
lspdADRindex = 0

function getDangerosityNameByInt(dangerosity)
    if dangerosityTable[dangerosity] ~= nil then
        return dangerosityTable[dangerosity]
    else
        return dangerosity
    end
end

RegisterNetEvent("yazho:adrGet")
AddEventHandler("yazho:adrGet", function(result)
    local found = 0
    for k,v in pairs(result) do
        found = found + 1
    end
    if found > 0 then lspdADRData = result end
end)

local function starts(String, Start)
    return string.sub(String, 1, string.len(Start)) == Start
end

local filterArray = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" }
local filter = 1

function Menuf6Police()
	local main = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
	main:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local inter = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	inter:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local info = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	info:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local renfort = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	renfort:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local voiture = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	voiture:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local chien = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	chien:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local lspd_main = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	lspd_main:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local lspd_adr = RageUI.CreateSubMenu(lspd_main, "POLICE", "MENU D'INTERACTIONS")
	lspd_adr:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local lspd_adrcheck = RageUI.CreateSubMenu(lspd_adr, "POLICE", "MENU D'INTERACTIONS")
	lspd_adrcheck:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local lspd_adrlaunch = RageUI.CreateSubMenu(lspd_main, "POLICE", "MENU D'INTERACTIONS")
	lspd_adrlaunch:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local gestGAV = RageUI.CreateSubMenu(inter, "POLICE", "MENU D'INTERACTIONS")
	gestGAV:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local objets = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	objets:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    local PropsMenu = RageUI.CreateSubMenu(objets, "POLICE", "MENU D'INTERACTIONS")
	PropsMenu:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    local PropsMenuobject = RageUI.CreateSubMenu(objets, "POLICE", "MENU D'INTERACTIONS")
	PropsMenuobject:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    local PropsMenuobjectlist = RageUI.CreateSubMenu(objets, "POLICE", "MENU D'INTERACTIONS")
	PropsMenuobjectlist:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	local label = "Actions Policières"

	RageUI.Visible(main, not RageUI.Visible(main))
	while main do
		Citizen.Wait(0)
			RageUI.IsVisible(main, true, true, true, function()
			RageUI.Checkbox(label, nil, policeserv, { Style = RageUI.CheckboxStyle.Tick }, function(Hovered, Selected, Active, Checked)
				policeserv = Checked;
			end, function()
				onservice = true
				TriggerServerEvent('police:PriseEtFinservice', "prise")
				TriggerServerEvent('yazho:logsEvent', "(STEAM) {"..GetPlayerName(PlayerId()).."} a pris son service.", Config.logs.PriseFinService)
				label = "Actions Policières"
			end, function()
				onservice = false
				TriggerServerEvent('police:PriseEtFinservice', "fin")
				TriggerServerEvent('yazho:logsEvent', "(STEAM) {"..GetPlayerName(PlayerId()).."} a quitté son service.", Config.logs.PriseFinService)
				label = "Actions Policières"
			end)
			if onservice then
				RageUI.Line()
				RageUI.Separator("Actions Globales")
				RageUI.Button("Actions sur Autrui(s)", nil, {RightLabel = "→→"}, true, {}, inter)
				RageUI.Button("Actions sur Véhicule(s)", nil, {RightLabel = "→→"}, true, {}, voiture)
				RageUI.Button("Actions Radio", nil, {RightLabel = "→→"}, true, {}, info)
				if ESX.PlayerData.job.grade >= Config.PermRecherche then
				RageUI.Button("Avis de Recherche", nil, {RightLabel = "→→"}, true, {}, lspd_main)
				end
				if ESX.PlayerData.job.grade >= Config.PermObjet then
				RageUI.Separator("Interactions Multiples")
				RageUI.Button("Gestion d'Objets", nil, {RightLabel = "→→"}, true, {}, objets)
				end
				if ESX.PlayerData.job.grade >= Config.PermChien then
				RageUI.Button("Intéractions Canine", nil, {RightLabel = "→→"}, true, {}, chien)
				end
			end
		end, function()
		end)

		local showMirandaRights = false

		function DrawMirandaRights()
			local x, y = 0.85, 0.23
			local width, height = 0.25, 0.38
			local textScale = 0.25
			local lineHeight = 0.03 
			
			DrawRect(x, y, width, height, 0, 0, 0, 200)

			local mirandaLines = {
		"Monsieur / Madame (Prénom et nom de la personne),",
        "je vous arrête pour (motif de l'arrestation).",
        "Vous avez le droit de garder le silence.",
        "Si vous renoncez à ce droit, tout ce que vous direz pourra",
        "être et sera utilisé contre vous.",
        "Vous avez le droit à un avocat, si vous n’en avez pas les moyens,",
        "un avocat vous sera fourni.",
        "",
        "Vous avez le droit à une assistance médicale ainsi qu'à de la",
        "nourriture et de l'eau.",
        "",
        "Avez-vous bien compris vos droits ?"
			}
			
			SetTextFont(0)
			SetTextProportional(1)
			SetTextScale(textScale, textScale)
			SetTextColour(255, 255, 255, 255)
			SetTextCentre(true)
			
			for i, line in ipairs(mirandaLines) do
				SetTextEntry("STRING")
				AddTextComponentString(line)
				DrawText(x, y - 0.2 + (i * lineHeight))
				SetTextFont(0)
				SetTextProportional(1)
				SetTextScale(textScale, textScale)
				SetTextColour(255, 255, 255, 255)
				SetTextCentre(true)
			end
		end
		
		Citizen.CreateThread(function()
			while true do
				Citizen.Wait(0)
				if showMirandaRights then
					DrawMirandaRights()
				end
			end
		end)
		
		function HasItem(item)
			local player = ESX.GetPlayerData()
			for _, v in pairs(player.inventory) do
				if v.name == item and v.count > 0 then
					return true
				end
			end
			return false
		end

		local remainingTime = 0
		
		
	RageUI.IsVisible(inter, true, true, true, function()
		RageUI.Button('Gestion G.A.V', nil, {RightLabel = "→→"}, true, {
			onSelected = function()
				ESX.TriggerServerCallback('yazho:getAllPlayerInGAV', function(result)
					playersInGAV = result
				end)
			end
		}, gestGAV)

		RageUI.Button("Droit Miranda ~m~(15sec d'affichage)~s~", nil, {RightLabel = "→"}, true, {
			onSelected = function()   
				showMirandaRights = true
				remainingTime = 15 -- Initialise le compte à rebours à 15 secondes
				Citizen.CreateThread(function()
					while remainingTime > 0 and showMirandaRights do
						Citizen.Wait(1000) -- Attendre 1 seconde
						remainingTime = remainingTime - 1
					end
					showMirandaRights = false -- Désactiver après le compte à rebours
				end)
			end
		})
		
		RageUI.Line()
		RageUI.Separator("Intéractions sur Autrui")
		RageUI.Button("Amender le Joueur ~m~(regarder le marker)~s~", nil, {RightLabel = "→"}, true, {
			onActive = function()
				MarquerJoueur()
			end,
			onSelected = function()
				local player, distance = ESX.Game.GetClosestPlayer()
						local raison = ""
						local montant = 0
						AddTextEntry("FMMC_MPM_NA", "Objet de la facture")
						DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Donnez le motif de la facture :", "", "", "", "", 30)
						while (UpdateOnscreenKeyboard() == 0) do
							DisableAllControlActions(0)
							Wait(0)
						end
						if (GetOnscreenKeyboardResult()) then
							local result = GetOnscreenKeyboardResult()
							if result then
								raison = result
								result = nil
								AddTextEntry("FMMC_MPM_NA", "Montant de la facture")
								DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Indiquez le montant de la facture :", "", "", "", "", 30)
								while (UpdateOnscreenKeyboard() == 0) do
									DisableAllControlActions(0)
									Wait(0)
								end
								if (GetOnscreenKeyboardResult()) then
									result = GetOnscreenKeyboardResult()
									if result then
										montant = result
										result = nil
										if player ~= -1 and distance <= 3.0 then
											TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(player), 'society_police', ('Police'), montant)
											TriggerEvent('esx:showNotification', 'Facture de '..montant.. '$ envoyée.')
											TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()) .. " a envoyé une facture de " .. montant .. "$ pour " .. raison .. " à " .. GetPlayerName(GetPlayerServerId(player))..".```", Config.logs.FactureAmende)
										else
											RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
										end
									end
								end
							end
						end
			end		
		})
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if Config.MenotteItem == true then
			RageUI.Button("Menotter/Démenotter ~m~(regarder le marker)~s~", nil, {RightLabel = "→"}, true, {
				onActive = function()
					MarquerJoueur()
				end,
				onSelected = function()
					local item = "menottes"
					if HasItem(item) then
					local target, distance = ESX.Game.GetClosestPlayer()
					playerheading = GetEntityHeading(GetPlayerPed(-1))
					playerlocation = GetEntityForwardVector(PlayerPedId())
					playerCoords = GetEntityCoords(GetPlayerPed(-1))
					local target_id = GetPlayerServerId(target)
					if closestPlayer ~= -1 and closestDistance <= 3.0 then
					TriggerServerEvent('yazhopolice:handcuff', GetPlayerServerId(closestPlayer))
					TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()) .. " a menotté " .. GetPlayerName(GetPlayerServerId(closestPlayer))..".```", Config.logs.Fouille)
					end
				else
					RageUI.Popup({message = "~r~Vous n'avez pas de menottes."})
					end
	
				end
			})
		end
		if Config.MenotteItem == false then
			RageUI.Button("Menotter/Démenotter le Joueur ~m~(regarder le marker)~s~", nil, {RightLabel = "→"}, true, {
				onActive = function()
					MarquerJoueur()
				end,
				onSelected = function()
					local target, distance = ESX.Game.GetClosestPlayer()
					playerheading = GetEntityHeading(GetPlayerPed(-1))
					playerlocation = GetEntityForwardVector(PlayerPedId())
					playerCoords = GetEntityCoords(GetPlayerPed(-1))
					local target_id = GetPlayerServerId(target)
					if closestPlayer ~= -1 and closestDistance <= 3.0 then
					TriggerServerEvent('yazhopolice:handcuff', GetPlayerServerId(closestPlayer))
					TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()) .. " a menotté " .. GetPlayerName(GetPlayerServerId(closestPlayer))..".```", Config.logs.Fouille)
				else
					RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
					end
				end
			})
		end
            RageUI.Button("Escorter le Joueur ~m~(regarder le marker)~s~", "(Le Joueur doit être menotté.)", {RightLabel = "→"}, true, {
				onActive = function()
					MarquerJoueur()
				end,
                onSelected = function()
					local target, distance = ESX.Game.GetClosestPlayer()
					playerheading = GetEntityHeading(GetPlayerPed(-1))
					playerlocation = GetEntityForwardVector(PlayerPedId())
					playerCoords = GetEntityCoords(GetPlayerPed(-1))
					local target_id = GetPlayerServerId(target)
					if closestPlayer ~= -1 and closestDistance <= 3.0 then
                TriggerServerEvent('yazhopolice:drag', GetPlayerServerId(closestPlayer))
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()) .. " a escorté " .. GetPlayerName(GetPlayerServerId(closestPlayer))..".```", Config.logs.Fouille)
			else
				RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
			end
        	end
        })
			RageUI.Line()
			RageUI.Separator("Actions Dépendantes")
            RageUI.Button("Mettre dans un véhicule ~m~(véhicule le plus proche)~s~", nil, {RightLabel = "→"}, true, {
				onActive = function()
					MarquerJoueur()
				end,
                onSelected = function()
					local target, distance = ESX.Game.GetClosestPlayer()
					playerheading = GetEntityHeading(GetPlayerPed(-1))
					playerlocation = GetEntityForwardVector(PlayerPedId())
					playerCoords = GetEntityCoords(GetPlayerPed(-1))
					local target_id = GetPlayerServerId(target)
					if closestPlayer ~= -1 and closestDistance <= 3.0 then
                TriggerServerEvent('yazhopolice:putInVehicle', GetPlayerServerId(closestPlayer))
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()) .. " a mis " .. GetPlayerName(GetPlayerServerId(closestPlayer)) .. " dans un véhicule.```", Config.logs.Fouille)
			else
				RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
			end
			end
            })

            RageUI.Button("Sortir du véhicule ~m~(véhicule le plus proche)~s~", nil, {RightLabel = "→"}, true, {
				onActive = function()
					MarquerJoueur()
				end,
                onSelected = function()
					local target, distance = ESX.Game.GetClosestPlayer()
					playerheading = GetEntityHeading(GetPlayerPed(-1))
					playerlocation = GetEntityForwardVector(PlayerPedId())
					playerCoords = GetEntityCoords(GetPlayerPed(-1))
					local target_id = GetPlayerServerId(target)
					if closestPlayer ~= -1 and closestDistance <= 3.0 then
                TriggerServerEvent('yazhopolice:OutVehicle', GetPlayerServerId(closestPlayer))
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()) .. " a sorti " .. GetPlayerName(GetPlayerServerId(closestPlayer)) .. " du véhicule.```", Config.logs.Fouille)
			else
				RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
			end
			end
        })

    end, function()
	end)

	Citizen.CreateThread(function()
		while true do
			Citizen.Wait(0)
			if showMirandaRights then
				SetTextFont(4)
				SetTextProportional(1)
				SetTextScale(0.4, 0.4)
				SetTextColour(255, 255, 255, 255)
				SetTextDropShadow(0, 0, 0, 0, 255)
				SetTextEdge(1, 0, 0, 0, 255)
				SetTextOutline()
				SetTextEntry("STRING")
				AddTextComponentString("Temps restant : " .. remainingTime .. " secondes.")
				DrawText(0.91, 0.42)
			end
		end
	end)
	
	local targetPosition = vector3(695.5223, -1005.85, 22.874)
	RageUI.IsVisible(objets, true, true, true, function()
		RageUI.Checkbox("Bouclier ~m~(uniquement avec arme)~s~",nil, bouclier,{},function(Hovered,Ative,Selected,Checked)
			if Selected then
				bouclier = Checked
				if Checked then
					EnableShield()
					
				else
					DisableShield()
				end
			end
		end)
		if Config.ReventeSaisies == true then
			RageUI.Line()
			RageUI.Separator("Actions sur les Saisies")
			RageUI.Button("Obtenir le point de Vente", nil, {RightLabel = "→"}, true, {
				onSelected = function()
					SetNewWaypoint(targetPosition.x, targetPosition.y)
					ESX.ShowNotification("Point placé sur la carte.")
				end
			})
		end
		RageUI.Line()
		RageUI.Separator("Menu(s) Disponible(s)")
		RageUI.Button("Menu Props", nil, { RightLabel = "→→" }, true, {}, PropsMenuobject)
		RageUI.Button("Menu de Suppression", nil, { RightLabel = "→→" }, true, {}, PropsMenuobjectlist)

    end, function()
	end)

		RageUI.IsVisible(info, true, true, true, function()
		RageUI.Separator('Demandes de Renfort(s)')
		RageUI.Button("Petite demande",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local raison = 'petit'
				local elements  = {}
				local playerPed = PlayerPedId()
				local coords  = GetEntityCoords(playerPed)
				local name = GetPlayerName(PlayerId())
			TriggerServerEvent('renfort', coords, raison)
			end
		})
			RageUI.Button("Moyenne demande",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					local raison = 'importante'
					local elements  = {}
					local playerPed = PlayerPedId()
					local coords  = GetEntityCoords(playerPed)
					local name = GetPlayerName(PlayerId())
				TriggerServerEvent('renfort', coords, raison)
			end
		})
		RageUI.Button("Forte demande",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local raison = 'omgad'
				local elements  = {}
				local playerPed = PlayerPedId()
				local coords  = GetEntityCoords(playerPed)
				local name = GetPlayerName(PlayerId())
			TriggerServerEvent('renfort', coords, raison)
		end
	})
		RageUI.Line()
        RageUI.Separator("Informations Radio")
		RageUI.Button("Prise de service",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local info = 'prise'
				TriggerServerEvent('police:PriseEtFinservice', info)	
			end
		})
		RageUI.Button("Fin de service",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local info = 'fin'
				TriggerServerEvent('police:PriseEtFinservice', info)	
			end
		})
		RageUI.Button("Pause de service",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local info = 'pause'
				TriggerServerEvent('police:PriseEtFinservice', info)	
			end
		})
		RageUI.Button("Standby",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local info = 'standby'
				TriggerServerEvent('police:PriseEtFinservice', info)	
			end
		})
		RageUI.Button("Control en cours",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local info = 'control'
				TriggerServerEvent('police:PriseEtFinservice', info)	
			end
		})
		RageUI.Button("Refus d'obtempérer",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local info = 'refus'
				TriggerServerEvent('police:PriseEtFinservice', info)	
			end
		})
		RageUI.Button("Crime en cours",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				local info = 'crime'
				TriggerServerEvent('police:PriseEtFinservice', info)
			end
		})
    end, function()
	end)

			RageUI.IsVisible(voiture, true, true, true, function()
			if ESX.PlayerData.job.grade >= Config.PermRadar then
				RageUI.Separator("Actions Indirectes")
				RageUI.Line()
				RageUI.Button("Positionner/Récupérer un Radar ~m~(entrez la vitesse)~s~",nil, {RightLabel = "→"}, true, {
					onSelected = function()
						TriggerEvent('police:POLICE_radar')
					end
				})
			end
			RageUI.Separator("Actions Directes")
			RageUI.Line()
			RageUI.Button("Rechercher une plaque ~m~(ensuite appuyez f8)~s~",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					LookupVehicle()
					RageUI.CloseAll()
				end
			})
			RageUI.Button("Mettre en fourrière ~m~(véhicule le plus proche)~s~", nil, { RightLabel = "→" }, true, {
                onSelected = function()
                    local playerPed = PlayerPedId()
                    if IsPedSittingInAnyVehicle(playerPed) then
                        local vehicle = GetVehiclePedIsIn(playerPed, false)
                        if GetPedInVehicleSeat(vehicle, -1) == playerPed then
                            ESX.Game.DeleteVehicle(vehicle)
							RageUI.Popup({message = "La voiture à été placer en fourriere"})
                        else
							RageUI.Popup({message = "Met toi place conducteur, ou sortez de la voiture."})
                        end
                    else
                        local vehicle = ESX.Game.GetVehicleInDirection()
                        if DoesEntityExist(vehicle) then
                            TaskStartScenarioInPlace(PlayerPedId(), 'WORLD_HUMAN_CLIPBOARD', 0, true)
                            Citizen.Wait(5000)
                            ClearPedTasks(playerPed)
                            ESX.Game.DeleteVehicle(vehicle)
							RageUI.Popup({message = "La voiture à été placer en fourriere"})
                        else
							RageUI.Popup({message = "Aucun véhicule autour"})
                        end
                    end
                end
            })
			RageUI.Button("Crocheter le véhicule ~m~(véhicule le plus proche)~s~", nil, {RightLabel = "→"}, true, {
				onSelected = function()
					local playerPed = PlayerPedId()
					local vehicle = ESX.Game.GetVehicleInDirection()
					local coords = GetEntityCoords(playerPed)
					if IsPedSittingInAnyVehicle(playerPed) then
						RageUI.Popup({message = "Merci de sortir du Véhicule."})
						return
					end
					if DoesEntityExist(vehicle) then
						isBusy = true
						TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_WELDING', 0, true)
						Citizen.CreateThread(function()
							Citizen.Wait(10000)
							SetVehicleDoorsLocked(vehicle, 1)
							SetVehicleDoorsLockedForAllPlayers(vehicle, false)
							ClearPedTasksImmediately(playerPed)
							RageUI.Popup({message = "Véhicule Crocheté."})
							isBusy = false
						end)
					else
						RageUI.Popup({message = "~r~Aucun Véhicule à Proximité."})
					end
				end
			})
	end, function()
	end)

	RageUI.IsVisible(chien, true, true, true, function()
			RageUI.Button("Sortir/Rentrer le Chien",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					if not DoesEntityExist(policeDog) then
                        RequestModel(351016938)
                        while not HasModelLoaded(351016938) do Wait(0) end
                        policeDog = CreatePed(4, 351016938, GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, 1.0, -0.98), 0.0, true, false)
                        SetEntityAsMissionEntity(policeDog, true, true)
						RageUI.Popup({message = "Le Chien est apparu."})
                    else
						RageUI.Popup({message = "Le Chien est rentré."})
                        DeleteEntity(policeDog)
                    end
					
				end
			})
			RageUI.Separator("Actions Disponibles")
			RageUI.Line()
			RageUI.Button("Assis",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					if DoesEntityExist(policeDog) then
                        if GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), GetEntityCoords(policeDog), true) <= 5.0 then
                            if IsEntityPlayingAnim(policeDog, "creatures@rottweiler@amb@world_dog_sitting@base", "base", 3) then
                                ClearPedTasks(policeDog)
                            else
                                loadDict('rcmnigel1c')
                                TaskPlayAnim(PlayerPedId(), 'rcmnigel1c', 'hailing_whistle_waive_a', 8.0, -8, -1, 120, 0, false, false, false)
                                Wait(2000)
                                loadDict("creatures@rottweiler@amb@world_dog_sitting@base")
                                TaskPlayAnim(policeDog, "creatures@rottweiler@amb@world_dog_sitting@base", "base", 8.0, -8, -1, 1, 0, false, false, false)
                            end
                        else
							RageUI.Popup({message = "~r~Votre chien est mort."})
                        end
                    else
						RageUI.Popup({message = "~r~Vous n\'avez pas de chien."})
                    end
				end
			})
		RageUI.Button("Dire d'Attaquer",nil, {RightLabel = "→"}, true, {
			onSelected = function()
				if DoesEntityExist(policeDog) then
					if not IsPedDeadOrDying(policeDog) then
						if GetDistanceBetweenCoords(GetEntityCoords(policeDog), GetEntityCoords(PlayerPedId()), true) <= 3.0 then
							local player, distance = ESX.Game.GetClosestPlayer()
							if distance ~= -1 then
								if distance <= 3.0 then
									local playerPed = GetPlayerPed(player)
									if not IsPedInCombat(policeDog, playerPed) then
										if not IsPedInAnyVehicle(playerPed, true) then
											TaskCombatPed(policeDog, playerPed, 0, 16)
										end
									else
										ClearPedTasksImmediately(policeDog)
									end
								end
							end
						end
					else
						RageUI.Popup({message = "~r~Votre chien est mort."})
					end
				else
					RageUI.Popup({message = "~r~Vous n\'avez pas de chien."})
			end
		end
	})
    end, function()
	end)

	RageUI.IsVisible(lspd_main, true, true, true, function()
		RageUI.Button("Consulter les avis de recherche", nil, {RightLabel = "→→"}, true, {
			onSelected = function()
				lspdADRData = nil
				TriggerServerEvent("yazho:adrGet")
			end
		}, lspd_adr)
		RageUI.Line()
		RageUI.Separator("Actions Disponibles")
		RageUI.Button("Ajouter un avis de recherche", nil, {RightLabel = "→→"}, true, {
		}, lspd_adrlaunch)
	end, function()    
	end, 1)

	RageUI.IsVisible(lspd_adr, true, true, true, function()
		lspdADRData = lspdADRData or {}
		filterArray = filterArray or {}
		filter = filter or 1
		RageUI.List("Filtre :", filterArray, filter, nil, {}, true, function(_, _, _, i)
			filter = i
		end)
		if next(lspdADRData) == nil then
			RageUI.Separator("~r~Aucun avis de recherche")
		else
			RageUI.Line()
			for index, adr in pairs(lspdADRData) do
				if adr and adr.firstname and starts(adr.firstname:lower(), filterArray[filter]:lower()) then
					RageUI.Button("(~b~nv." .. adr.dangerosity .. "~s~) " .. adr.firstname .. " " .. adr.lastname, nil, { RightLabel = "→" }, true, {
						onSelected = function()
							lspdADRindex = index
						end
					}, lspd_adrcheck)
				end
			end
		end
	end, function()
	end, 1)

	RageUI.IsVisible(lspd_adrlaunch, true, true, true, function()
		RageUI.Button("Entrez le Nom", nil, { RightLabel = lspdADRBuilder.lastname ~= nil and lspdADRBuilder.lastname ~= "" and lspdADRBuilder.lastname or "AUCUN" }, true, {
			onSelected = function()
				lspdADRBuilder.lastname = KeyboardInput("Prénom", "", 10)
			end
		})
		RageUI.Button("Entrez le Prénom", nil, { RightLabel = lspdADRBuilder.firstname ~= nil and lspdADRBuilder.firstname ~= "" and lspdADRBuilder.firstname or "AUCUN" }, true, {
			onSelected = function()
				lspdADRBuilder.firstname = KeyboardInput("Prénom", "", 10)
			end
		})
		RageUI.Button("Entrez le Motif", nil, { RightLabel = lspdADRBuilder.reason ~= nil and lspdADRBuilder.reason ~= "" and lspdADRBuilder.reason or "AUCUN" }, true, {
			onSelected = function()
				lspdADRBuilder.reason = KeyboardInput("Prénom", "", 100)
			end
		})
		RageUI.List("Saisir une Dangerosité", lspdADRDangerosities, lspdADRBuilder.dangerosity, nil, {}, true, function(Hovered, Active, Selected, Index)
			lspdADRBuilder.dangerosity = Index
		end)
		RageUI.Button("~g~Ajouter", nil, { RightLabel = "→→" }, lspdADRBuilder.firstname ~= nil and lspdADRBuilder.lastname ~= nil and lspdADRBuilder.reason ~= nil, {
			onSelected = function()
				RageUI.GoBack()
				TriggerServerEvent("yazho:adrAdd", lspdADRBuilder)
				lspdADRBuilder = {dangerosity = 1}
				RageUI.Popup({message = "Avis de recherche ajouté à la Base de Données."})
			end
		})
	end, function()    
	end, 1)

	RageUI.IsVisible(lspd_adrcheck, true, true, true, function()
		if lspdADRindex and lspdADRData[lspdADRindex] then
			local adr = lspdADRData[lspdADRindex]
			RageUI.Separator("Dépositaire - "..(adr.author or "Inconnu"))
			RageUI.Separator("Le "..(adr.date or "Inconnue"))
			RageUI.Separator("~b~"..(adr.lastname or "Inconnu").." "..(adr.firstname or "Inconnu"))
			RageUI.Separator("Dangerosité de Niveau ("..(getDangerosityNameByInt(adr.dangerosity) or "Inconnue")..")")
			RageUI.Separator("Raison(s) - "..(adr.reason or "Non spécifiée"))
			if ESX.PlayerData.job.grade and ESX.PlayerData.job.grade >= 4 then
				RageUI.Line()
				RageUI.Separator("Action(s) Disponible(s)")
				RageUI.Button("Supprimer l'Avis de Recherche", nil, { RightLabel = "→→" }, true, {
					onSelected = function()
						RageUI.GoBack()
						TriggerServerEvent("yazho:adrDel", lspdADRindex)
						RageUI.Popup({ message = "Avis de recherche retiré de la Base de Données." })
					end
				})
			end
		else
			RageUI.Separator("~r~Données indisponibles.")
		end
	end, function()
	end, 1)

	RageUI.IsVisible(PropsMenuobject, true, true, true, function()
		RageUI.Button("{PROPS} Cone ~m~(figé)~s~", "(Appuyez {E} pour poser.)", {RightLabel = "→"}, true, {
			onSelected = function()
				SpawnObj("prop_roadcone02a")
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()).." a spawné un cone.```", Config.logs.Objets)
			end
		})
		RageUI.Button("{PROPS} Barrière ~m~(figé)~s~", "(Appuyez {E} pour poser.)", {RightLabel = "→"}, true, {
			onSelected = function()
				SpawnObj("prop_barrier_work05")
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()).." a spawné une barrière.```", Config.logs.Objets)
			end
		})
		RageUI.Button("{PROPS} Gros carton ~m~(figé)~s~", "(Appuyez {E} pour poser.)", {RightLabel = "→"}, true, {
			onSelected = function()
				SpawnObj("prop_boxpile_07d")
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()).." a spawné un gros carton.```", Config.logs.Objets)
			end
		})
		RageUI.Button("{PROPS} Herse ~m~(figé)~s~", "(Appuyez {E} pour poser.)", {RightLabel = "→"}, true, {
			onSelected = function()
				SpawnObj("p_ld_stinger_s")
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()).." a spawné une herse.```", Config.logs.Objets)
			end
		})
		RageUI.Button("{PROPS} Cash ~m~(figé)~s~", "(Appuyez {E} pour poser.)", {RightLabel = "→"}, true, {
			onSelected = function()
				SpawnObj("hei_prop_cash_crate_half_full")
				TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()).." a spawné un cash.```", Config.logs.Objets)
			end
		})
		end, function()
		end)

		RageUI.IsVisible(PropsMenuobjectlist, true, true, true, function()
				for k,v in pairs(object) do
					if GoodName(GetEntityModel(NetworkGetEntityFromNetworkId(v))) == 0 then table.remove(object, k) end
					RageUI.Button("Props - "..GoodName(GetEntityModel(NetworkGetEntityFromNetworkId(v))).." ["..v.."]", nil, {}, true, {
						onActive = function()
							local entity = NetworkGetEntityFromNetworkId(v)
							local ObjCoords = GetEntityCoords(entity)
							DrawMarker(42, ObjCoords.x, ObjCoords.y, ObjCoords.z+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
						end,
						onSelected = function()
							RemoveObj(v, k)
							TriggerServerEvent("yazho:logsEvent", "```"..GetPlayerName(PlayerId()).." a supprimé un objet ("..GoodName(GetEntityModel(NetworkGetEntityFromNetworkId(v)))..").```", Config.logs.Objets)
						end
					})
				end
			
		end, function()
		end)

		RageUI.IsVisible(gestGAV, true, true, true, function()
			RageUI.Separator(#playersInGAV.." personnes sont en G.A.V.")
			RageUI.Line()
			local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
			RageUI.Button("Ajouter le Joueur en G.A.V.",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					if closestPlayer ~= -1 and closestDistance <= 3.0 then
						TriggerServerEvent("yazho:addPlayerInGAV", GetPlayerServerId(closestPlayer))
						ESX.TriggerServerCallback('yazho:getAllPlayerInGAV', function(result)
							playersInGAV = result
						end)
					else
						RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
					end
					cooldowncool(1000)
				end
			})
			RageUI.Button("Retirer le Joueur de la G.A.V.",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					if closestPlayer ~= -1 and closestDistance <= 3.0 then
						TriggerServerEvent("yazho:removePlayerInGAV", GetPlayerServerId(closestPlayer))
						ESX.TriggerServerCallback('yazho:getAllPlayerInGAV', function(result)
							playersInGAV = result
						end)
					else
						RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
					end
					cooldowncool(1000)
				end
			})
			RageUI.Line()
			RageUI.Separator("Action(s) sur Soi-Même")
			RageUI.Button("Se Mettre en G.A.V.",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					TriggerServerEvent("yazho:addPlayerInGAV", GetPlayerServerId(PlayerId()))
					ESX.TriggerServerCallback('yazho:getAllPlayerInGAV', function(result)
						playersInGAV = result
					end)
					cooldowncool(1000)
				end
			})
			RageUI.Button("Se Retirer de la G.A.V.",nil, {RightLabel = "→"}, true, {
				onSelected = function()
					TriggerServerEvent("yazho:removePlayerInGAV", GetPlayerServerId(PlayerId()))
					ESX.TriggerServerCallback('yazho:getAllPlayerInGAV', function(result)
						playersInGAV = result
					end)
					cooldowncool(1000)
				end
			})
		end, function()
		end)

	if not RageUI.Visible(main) and not RageUI.Visible(inter) and not RageUI.Visible(info) and not RageUI.Visible(renfort) and not RageUI.Visible(chien) and not RageUI.Visible(voiture) and not RageUI.Visible(lspd_main) and not RageUI.Visible(lspd_adrcheck) and not RageUI.Visible(lspd_adr) and not RageUI.Visible(lspd_adrlaunch) and not RageUI.Visible(gestGAV) and not RageUI.Visible(objets) and not RageUI.Visible(PropsMenu) and not RageUI.Visible(PropsMenuobject) and not RageUI.Visible(PropsMenuobjectlist) then
		main = RMenu:DeleteType(main, true)
	end
end
end

Keys.Register('F6', 'Police', 'Ouvrir le menu Police', function()
	if ESX.PlayerData.job and ESX.PlayerData.job.name == 'police' then
    	Menuf6Police()
	end
end)

RegisterNetEvent('renfort:setBlip')
AddEventHandler('renfort:setBlip', function(coords, raison)
	if raison == 'petit' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "OOB_Start", "GTAO_FM_Events_Soundset", 1)
		ESX.ShowNotification("Demande de renfort d'Importance (~g~Légère~s~) en cours.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
		color = 2
	elseif raison == 'importante' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "OOB_Start", "GTAO_FM_Events_Soundset", 1)
		ESX.ShowNotification("Demande de renfort d'Importance (~o~Moyenne~s~) en cours.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
		color = 47
	elseif raison == 'omgad' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "OOB_Start", "GTAO_FM_Events_Soundset", 1)
		PlaySoundFrontend(-1, "FocusIn", "HintCamSounds", 1)
		ESX.ShowNotification("Demande de renfort d'Importance (~r~Forte~s~) en cours.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
		PlaySoundFrontend(-1, "FocusOut", "HintCamSounds", 1)
		color = 1
	end
	local blipId = AddBlipForCoord(coords)
	SetBlipSprite(blipId, 161)
	SetBlipScale(blipId, 1.2)
	SetBlipColour(blipId, color)
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString('Demande renfort')
	EndTextCommandSetBlipName(blipId)
	Wait(80 * 1000)
	RemoveBlip(blipId)
end)

RegisterNetEvent('police:InfoService')
AddEventHandler('police:InfoService', function(service, name)
	if service == 'prise' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		ESX.ShowNotification("("..name..") est en service.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
	elseif service == 'fin' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		ESX.ShowNotification("("..name..") n'est plus en service.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
	elseif service == 'pause' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		ESX.ShowNotification("("..name..") est désormais en Pause.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
	elseif service == 'standby' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		ESX.ShowNotification("("..name..") est en Standbay.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
	elseif service == 'control' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		ESX.ShowNotification("("..name..") est en Contrôle.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
	elseif service == 'refus' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		ESX.ShowNotification("("..name..") signale un refus d'Obtempérer.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
	elseif service == 'crime' then
		PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1)
		ESX.ShowNotification("("..name..") signale qu'un Crime est en cours.")
		Wait(1000)
		PlaySoundFrontend(-1, "End_Squelch", "CB_RADIO_SFX", 1)
	end
end)

RegisterNetEvent('yazhopolice:handcuff')
AddEventHandler('yazhopolice:handcuff', function()

IsHandcuffed    = not IsHandcuffed;
local playerPed = GetPlayerPed(-1)

Citizen.CreateThread(function()

if IsHandcuffed then
	RequestAnimDict('mp_arresting')
	while not HasAnimDictLoaded('mp_arresting') do
		Citizen.Wait(100)
	end
	TaskPlayAnim(playerPed, 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0, 0, 0, 0)
	DisableControlAction(2, 37, true)
	SetEnableHandcuffs(playerPed, true)
	SetPedCanPlayGestureAnims(playerPed, false)
	FreezeEntityPosition(playerPed,  true)
	DisableControlAction(0, 24, true)
	DisableControlAction(0, 257, true)
	DisableControlAction(0, 25, true)
	DisableControlAction(0, 263, true)
	DisableControlAction(0, 37, true)
	DisableControlAction(0, 47, true)
	DisplayRadar(false)
else
	ClearPedSecondaryTask(playerPed)
	SetEnableHandcuffs(playerPed, false)
	SetPedCanPlayGestureAnims(playerPed,  true)
	FreezeEntityPosition(playerPed, false)
	DisplayRadar(true)
end
end)
end)

RegisterNetEvent('yazhopolice:drag')
AddEventHandler('yazhopolice:drag', function(cop)
  IsDragged = not IsDragged
  CopPed = tonumber(cop)
end)

Citizen.CreateThread(function()
  while true do
    Wait(0)
    if IsHandcuffed then
      if IsDragged then
        local ped = GetPlayerPed(GetPlayerFromServerId(CopPed))
        local myped = GetPlayerPed(-1)
        AttachEntityToEntity(myped, ped, 11816, 0.54, 0.54, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
      else
        DetachEntity(GetPlayerPed(-1), true, false)
      end
    end
  end
end)

RegisterNetEvent('yazhopolice:putInVehicle')
AddEventHandler('yazhopolice:putInVehicle', function()
  local playerPed = GetPlayerPed(-1)
  local coords    = GetEntityCoords(playerPed)
  if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 5.0) then
    local vehicle = GetClosestVehicle(coords.x,  coords.y,  coords.z,  5.0,  0,  71)
    if DoesEntityExist(vehicle) then
      local maxSeats = GetVehicleMaxNumberOfPassengers(vehicle)
      local freeSeat = nil
      for i=maxSeats - 1, 0, -1 do
        if IsVehicleSeatFree(vehicle,  i) then
          freeSeat = i
          break
        end
      end
      if freeSeat ~= nil then
        TaskWarpPedIntoVehicle(playerPed,  vehicle,  freeSeat)
      end
    end
  end
end)

RegisterNetEvent('yazhopolice:OutVehicle')
AddEventHandler('yazhopolice:OutVehicle', function(t)
  local ped = GetPlayerPed(t)
  ClearPedTasksImmediately(ped)
  plyPos = GetEntityCoords(GetPlayerPed(-1),  true)
  local xnew = plyPos.x+2
  local ynew = plyPos.y+2

  SetEntityCoords(GetPlayerPed(-1), xnew, ynew, plyPos.z)
end)

Citizen.CreateThread(function()
  while true do
    Wait(0)
    if IsHandcuffed then
      DisableControlAction(0, 142, true)
      DisableControlAction(0, 30,  true)
      DisableControlAction(0, 31,  true)
    end
  end
end)

function notNilString(str)
    if str == nil then
        return ""
    else
        return str
    end
end

function spawnObject(name)
	local plyPed = PlayerPedId()
	local coords = GetEntityCoords(plyPed, false) + (GetEntityForwardVector(plyPed) * 1.0)

	ESX.Game.SpawnObject(name, coords, function(obj)
		SetEntityHeading(obj, GetEntityPhysicsHeading(plyPed))
		PlaceObjectOnGroundProperly(obj)
	end)
end

local shieldActive = false
local shieldEntity = nil

local animDict = "combat@gestures@gang@pistol_1h@beckon"
local animName = "0"

local prop = "prop_ballistic_shield"

function EnableShield()
    shieldActive = true
    local ped = GetPlayerPed(-1)
    local pedPos = GetEntityCoords(ped, false)
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Citizen.Wait(250)
    end
    TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, (2 + 16 + 32), 0.0, 0, 0, 0)
    RequestModel(GetHashKey(prop))
    while not HasModelLoaded(GetHashKey(prop)) do
        Citizen.Wait(250)
    end
    local shield = CreateObject(GetHashKey(prop), pedPos.x, pedPos.y, pedPos.z, 1, 1, 1)
    shieldEntity = shield
    AttachEntityToEntity(shieldEntity, ped, GetEntityBoneIndexByName(ped, "IK_L_Hand"), 0.0, -0.05, -0.10, -30.0, 180.0, 40.0, 0, 0, 1, 0, 0, 1)
    SetWeaponAnimationOverride(ped, GetHashKey("Gang1H"))
    SetEnableHandcuffs(ped, true)
end

function DisableShield()
    local ped = GetPlayerPed(-1)
    DeleteEntity(shieldEntity)
    ClearPedTasksImmediately(ped)
    SetWeaponAnimationOverride(ped, GetHashKey("Default"))
    SetEnableHandcuffs(ped, false)
    shieldActive = false
end

Citizen.CreateThread(function()
    while true do
        if shieldActive then
            local ped = GetPlayerPed(-1)
            if not IsEntityPlayingAnim(ped, animDict, animName, 1) then
                RequestAnimDict(animDict)
                while not HasAnimDictLoaded(animDict) do
                    Citizen.Wait(100)
                end
            
                TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, (2 + 16 + 32), 0.0, 0, 0, 0)
            end
        end
        Citizen.Wait(500)
    end
end)

loadDict = function(dict)
    while not HasAnimDictLoaded(dict) do Wait(0) RequestAnimDict(dict) end
end

function OpenVehicleInfosMenu(vehicleData)
	ESX.TriggerServerCallback('yazhopolice:getVehicleInfos', function(retrivedInfo)
		local elements = {{label = ("Plaque" ..retrivedInfo.plate)}}
		if retrivedInfo.owner == nil then
			table.insert(elements, {label = ('Propriétaire inconnu')})
		else
			table.insert(elements, {label = ("Propriétaire" ..retrivedInfo.owner)})
		end
		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_infos', {
			css      = 'police',
			title    = ('Info véhicule'),
			align    = 'top-left',
			elements = elements
		}, nil, function(data, menu)
			menu.close()
		end)
	end, vehicleData.plate)
end

function LookupVehicle()
    local function KeyboardInput(textEntry, exampleText, maxStringLength)
        AddTextEntry('FMMC_KEY_TIP1', textEntry)
        DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", exampleText, "", "", "", maxStringLength)
        while UpdateOnscreenKeyboard() == 0 do
            Wait(0)
        end
        if GetOnscreenKeyboardResult() then
            return GetOnscreenKeyboardResult()
        end
        return nil
    end

    local input = KeyboardInput("Entrer le Numéro de Plaque.", "", 10)
    if input then
        local length = string.len(input)
        if length < 2 or length > 8 then
            print("^1Erreur : La saisie doit contenir entre 2 et 8 caractères.^0")
        else
            ESX.TriggerServerCallback('yazhopolice:getVehicleInfos', function(retrivedInfo)
                if not retrivedInfo then
                    print("^1Erreur : Aucune information trouvée pour l'entrée donnée.^0")
                    return
                end
				SetTextEntry_2("STRING")
				AddTextComponentString("INFORMATIONS DISPONIBLES DANS LE F8")
				DrawSubtitleTimed(6000, 1)
				print("^1INFORMATIONS VÉHICULE")
                print("Plaque : " .. (retrivedInfo.plate or "Inconnu"))

                if not retrivedInfo.owner then
                    print("Propriétaire : Inconnu")
                else
                    print("Propriétaire : " .. retrivedInfo.owner)
                end
            end, input)
        end
    else
        print("^1Aucune entrée n'a été donnée.^0")
    end
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        if IsPedShooting(playerPed) then
            local pos = GetEntityCoords(playerPed)
            TriggerServerEvent('police:shootNotification', pos)
        end
    end
end)


if Config.Alert == true then
    RegisterNetEvent('police:sendShootAlert')
    AddEventHandler('police:sendShootAlert', function(position)
		local playerJob = ESX.GetPlayerData().job.name
        if playerJob == 'police' then
            SetNotificationTextEntry("STRING")
            AddTextComponentString("Un tir a eu lieu, regardez votre carte.")
            DrawNotification(true, false)
            local blip = AddBlipForCoord(position.x, position.y, position.z)
            SetBlipSprite(blip, 161) 
            SetBlipColour(blip, 1) 
            SetBlipScale(blip, 1.0) 
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString('TIR')
            EndTextCommandSetBlipName(blip)
            Wait(60000)
            RemoveBlip(blip)
        end
    end)
end

local sellableItems = {
    {name = "Coffre-fort", price = 500, item = "goldbar"},
    {name = "Bijoux", price = 300, item = "diamond"},
    {name = "Téléphone", price = 100, item = "phone"}
}

function SellItem(item)
    local playerPed = PlayerPedId()
    TriggerServerEvent("sellItem", item.item, item.price)
    isMenuOpen = false
    RageUI.Visible(menu, false)
end

if Config.ReventeSaisies == true then
	function Reventte()
		local rvent = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
		rvent:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
		RageUI.Visible(rvent, not RageUI.Visible(rvent))
		while rvent do
			Citizen.Wait(0)
				RageUI.IsVisible(rvent, true, true, true, function()
					for _, item in ipairs(sellableItems) do
						RageUI.Button(item.name .. " / ~b~" .. item.price.."$", nil, {RightLabel = "→"}, true, {
							onSelected = function()
								SellItem(item)
							end
						})
					end
			end, function()
			end)
			if not RageUI.Visible(rvent) then
				rvent = RMenu:DeleteType("rvent", true)
			end
		end
	end
end
	
	Citizen.CreateThread(function()
		while true do
			local Timer = 800
			if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermAmu then
			local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
			local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, 695.5223, -1005.85, 22.874)
			if dist3 <= 5.0 then 
				Timer = 0
			DrawMarker(23, 695.5223, -1005.85, 22.874-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
			end
			if dist3 <= 3.0 then 
					Timer = 0
					ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder à la revente des Saisies.")
						if IsControlJustPressed(1,51) then
							Reventte()
						end   
					end
				end
			Citizen.Wait(Timer)
		end
	end)

	Citizen.CreateThread(function()
		local pedPos = vector3(696.3041, -1005.84, 21.888) 
		local pedModel = "a_m_m_business_01" 
		local heading = 84.644393920898
		RequestModel(pedModel)
		while not HasModelLoaded(pedModel) do
			Wait(500)
		end
		local ped = CreatePed(4, pedModel, pedPos.x, pedPos.y, pedPos.z, heading, false, true)
		TaskSetBlockingOfNonTemporaryEvents(ped, true)
		SetEntityInvincible(ped, true)
		FreezeEntityPosition(ped, true)
		TaskLookAtEntity(ped, ped, -1, 0, 2)
		Citizen.CreateThread(function()
			while true do
				Citizen.Wait(0)
				local markerPos = vector3(pedPos.x, pedPos.y, pedPos.z + 2)
				DrawMarker(29, markerPos.x, markerPos.y, markerPos.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, false, true, 2, nil, nil, false)
			end
		end)
	end)

	Citizen.CreateThread(function()
		local pedPos = vector3(452.8708, -972.029, 24.788)
		local pedModel = "cs_karen_daniels" 
		local heading = 194.00746154785
		RequestModel(pedModel)
		while not HasModelLoaded(pedModel) do
			Wait(500)
		end
		local ped = CreatePed(4, pedModel, pedPos.x, pedPos.y, pedPos.z, heading, false, true)
		TaskSetBlockingOfNonTemporaryEvents(ped, true)
		SetEntityInvincible(ped, true)
		FreezeEntityPosition(ped, true)
		TaskLookAtEntity(ped, ped, -1, 0, 2)
		Citizen.CreateThread(function()
			while true do
				Citizen.Wait(0)
				local markerPos = vector3(pedPos.x, pedPos.y, pedPos.z + 2)
				DrawMarker(36, markerPos.x, markerPos.y, markerPos.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, false, true, 2, nil, nil, false)
			end
		end)
	end)