local ESX = nil
local allLicensesClient = {}
local lSelected = {}
local indexMenu = 1
local TypeDispo = {
    [1] = 'drive',
    [2] = 'drive_bike',
    [3] = 'drive_truck',
    [4] = 'ppa',
    [5] = 'dmv'
}

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

local function menuPointLicenses()
    local menuP = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    local menuS = RageUI.CreateSubMenu(menuP, "POLICE", "MENU D'INTERACTIONS")
	menuP:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    menuS:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(menuP, not RageUI.Visible(menuP))
    while menuP do
        Citizen.Wait(0)
            RageUI.IsVisible(menuP, true, true, true, function()
                RageUI.List('Type de permis : ', {'Voiture', 'Moto', 'Camion', 'PPA', 'Code'}, indexMenu, nil, {}, true, function(Hovered, Active, Selected, Index)
                    indexMenu = Index
                end)
                for k,v in pairs(allLicensesClient) do
                    if v.Type == TypeDispo[indexMenu] then
                    RageUI.ButtonWithStyle(v.Name, nil, {RightLabel = "→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            lSelected = v
                        end
                    end, menuS)
                end
            end
        end)

        RageUI.IsVisible(menuS, true, true, true, function()
            RageUI.Separator(lSelected.Name.." - "..lSelected.Type)
            RageUI.Button("Supprimer le permis", nil, {RightLabel = "→"}, true, {
                onSelected = function()
                    TriggerServerEvent('yazhopermis:removePoint', lSelected.Type, qty, lSelected.Owner)
                    RageUI.CloseAll()
                    end
            })
        end)
        if not RageUI.Visible(menuP) and not RageUI.Visible(menuS) then
            menuP = RMenu:DeleteType("Menu Point", true)
        end
    end
end


Citizen.CreateThread(function()
    while true do
        local Timer = 800
        if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermGestPermis then
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.menuPermisInfo.position.x, Config.pos.menuPermisInfo.position.y, Config.pos.menuPermisInfo.position.z)
        if dist3 <= 15 then
            Timer = 0
			DrawMarker(23, Config.pos.menuPermisInfo.position.x, Config.pos.menuPermisInfo.position.y, Config.pos.menuPermisInfo.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
		end
            if dist3 <= 2.0 then
                Timer = 0   
                    ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder à la Gestion de Permis.")
                        if IsControlJustPressed(1,51) then
                            local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                            if closestPlayer ~= -1 and closestDistance <= 3.0 then
                                ESX.TriggerServerCallback('yazhopermis:getAllLicenses', function(result)
                                allLicensesClient = result
                                menuPointLicenses()
                            end, GetPlayerServerId(closestPlayer))
                            else
                                RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
                            end
                        end 
                end
            end 
        Citizen.Wait(Timer)
    end
end)