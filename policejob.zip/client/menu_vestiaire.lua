ESX = nil
local allCasier = {}
local allContentCasier = {}
local allWeaponInCasier = {}
local allItemsInCasier = {}
local allContentCasier2 = {}
local allWeaponInCasier2 = {}
local allItemsInCasier2 = {}
local ifHaveCasier = false
local identifierSelected = nil

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

local function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end

function CloackRoomPolice()
	local ckr = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
	local moncasier = RageUI.CreateSubMenu(ckr, "POLICE", "MENU D'INTERACTIONS")
    local moncasiersub = RageUI.CreateSubMenu(moncasier, "POLICE", "MENU D'INTERACTIONS")
    local moncasiersub2 = RageUI.CreateSubMenu(moncasier, "POLICE", "MENU D'INTERACTIONS")
	local depotobj = RageUI.CreateSubMenu(moncasier, "POLICE", "MENU D'INTERACTIONS")
	ckr:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	moncasier:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    moncasiersub:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    moncasiersub2:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	depotobj:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)

	RageUI.Visible(ckr, not RageUI.Visible(ckr))
	while ckr do
		Citizen.Wait(0)
			RageUI.IsVisible(ckr, true, true, true, function()
				RageUI.Button("Liste des Casiers", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        ESX.TriggerServerCallback('yazho:getIfHaveCasier', function(result)
                            ifHaveCasier = result
                        end)
                    end
				}, moncasier)
                RageUI.Line()
                RageUI.Separator("Action(s) Disponible(s)")
				RageUI.Separator(GetPlayerName(PlayerId()).. " - " ..ESX.PlayerData.job.grade_label)
                RageUI.Line()
                RageUI.Separator("Liste des Tenues")
					for index,infos in pairs(police.clothes.specials) do
						RageUI.Button(infos.label,nil, {RightLabel = "→"}, ESX.PlayerData.job.grade >= infos.minimum_grade, {
							onSelected = function()
								ApplySkin(infos)
							end
		    			})
					end
                RageUI.Line()
				for index,infos in pairs(police.clothes.grades) do
					RageUI.Button(infos.label,nil, {RightLabel = "→"}, ESX.PlayerData.job.grade >= infos.minimum_grade, {
					    onSelected = function()
                            ApplySkin(infos)
                            SetPedArmour(PlayerPedId(), 100)
					    end
                    })
                end
				end, function() 
				end)

				RageUI.IsVisible(moncasier, true, true, true, function()
                    RageUI.Button("Gérer Mon Casier", nil, {RightLabel = "→→"}, ifHaveCasier, {
                        onSelected = function()
                            getAllContentCasier()
                        end
                    }, moncasiersub)
                    RageUI.Line()
                    RageUI.Separator("Liste des Casiers")
                    for k,v in pairs(allCasier) do
                    for id,_ in pairs(json.decode(v.guest)) do
                        if id == ESX.PlayerData.identifier then
                        RageUI.Button(v.name, nil, {RightLabel = "→"}, true, {
                            onSelected = function()
                                getAllContentCasierNotOwner(v.owner)
                                identifierSelected = v.owner
                            end
                        }, moncasiersub2)
                    else
                        RageUI.Button(v.name, nil, {}, false, {})
                    end
                    end
                    end

                end, function()
                end)

                RageUI.IsVisible(moncasiersub, true, true, true, function()
                for k,v in pairs(allContentCasier) do
                    if v.type == "blackmoney" then
                    RageUI.Separator("Contenu (~r~ARGENT SALE~s~) - "..v.amount.."$")
                    elseif v.type == "cash" then
                    RageUI.Separator("Contenu (~g~ARGENT EN LIQUIDE~s~) - "..v.amount.."$")
                    end
                end
                RageUI.Line()
                RageUI.Separator("Gestion de l'Argent")
                RageUI.Button("Déposer du Liquide", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        local amount = KeyboardInput("Montant", "", 10)
                        if amount ~= nil then
                            TriggerServerEvent('yazho:addMoneyToCasier', tonumber(amount))
                            Citizen.Wait(500)
                            getAllContentCasier()
                        end
                    end
                })
                RageUI.Button("Retirer du Liquide", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        local amount = KeyboardInput("Montant", "", 10)
                        if amount ~= nil then
                            TriggerServerEvent('yazho:removeMoneyFromCasier', tonumber(amount))
                            Citizen.Wait(500)
                            getAllContentCasier()
                        end
                    end
                })
                RageUI.Button("Déposer de l'Argent Sale", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        local amount = KeyboardInput("Montant", "", 10)
                        if amount ~= nil then
                            TriggerServerEvent('yazho:addBlackMoneyToCasier', tonumber(amount))
                            Citizen.Wait(500)
                            getAllContentCasier()
                        end
                    end
                })
                RageUI.Button("Retirer de l'Argent Sale", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        local amount = KeyboardInput("Montant", "", 10)
                        if amount ~= nil then
                            TriggerServerEvent('yazho:removeBlackMoneyFromCasier', tonumber(amount))
                            Citizen.Wait(500)
                            getAllContentCasier()
                        end
                    end
                })
                RageUI.Line()
                RageUI.Separator("Gestion d'Objets")
                RageUI.Button("Déposer Objet(s)", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        menuDepoItems()
                    end
                })
                RageUI.Button("Retirer Objet(s)", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        menuRetraitItems()
                    end
                })
                RageUI.Line()
                RageUI.Separator("Gestion d'Armes (SI ARMES PAS = OBJETS)")

                RageUI.Button("Déposer Arme(s)", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        menuDepoWeapons()
                    end
                })
                RageUI.Button("Retirer Arme(s)", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        menuRetraitWeapons()
                    end
                })
                RageUI.Line()
                RageUI.Separator("Gestion du Casier")
                RageUI.Button("Ajouter un Joueur du Casier", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                        if closestPlayer ~= -1 and closestDistance <= 3.0 then
                            TriggerServerEvent("yazho:addPlayerToCasier", GetPlayerServerId(closestPlayer))
                        else
                            RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
                        end
                    end
                })
                RageUI.Button("Retirer un Joueur du Casier", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                        if closestPlayer ~= -1 and closestDistance <= 3.0 then
                            TriggerServerEvent("yazho:removePlayerFromCasier", GetPlayerServerId(closestPlayer))
                        else
                            RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
                        end
                    end
                })
                RageUI.Button("Retirer tout le monde du Casier", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()
                        TriggerServerEvent("yazho:clearCasier")
                    end
                })
                end, function()
                end)
                RageUI.IsVisible(moncasiersub2, true, true, true, function()
                    for k,v in pairs(allContentCasier2) do
                        if v.type == "blackmoney" then
                        RageUI.Separator("Contenu (~r~ARGENT SALE~s~) - "..v.amount.."$")
                        elseif v.type == "cash" then
                        RageUI.Separator("Contenu (~g~ARGENT EN LIQUIDE~s~) - "..v.amount.."$")
                        end
                    end
                    RageUI.Line()
                    RageUI.Separator("Gestion de l'Argent")
                    RageUI.Button("Déposer du Liquide", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            local amount = KeyboardInput("Montant", "", 10)
                            if amount ~= nil then
                                TriggerServerEvent('yazho:addMoneyToCasier2', tonumber(amount), identifierSelected)
                                Citizen.Wait(500)
                                getAllContentCasierNotOwner(identifierSelected)
                            end
                        end
                    })
                    RageUI.Button("Retirer du Liquide", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            local amount = KeyboardInput("Montant", "", 10)
                            if amount ~= nil then
                                TriggerServerEvent('yazho:removeMoneyFromCasier2', tonumber(amount), identifierSelected)
                                Citizen.Wait(500)
                                getAllContentCasierNotOwner(identifierSelected)
                            end
                        end
                    })
                    RageUI.Button("Déposer de l'Argent Sale", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            local amount = KeyboardInput("Montant", "", 10)
                            if amount ~= nil then
                                TriggerServerEvent('yazho:addBlackMoneyToCasier2', tonumber(amount), identifierSelected)
                                Citizen.Wait(500)
                                getAllContentCasierNotOwner(identifierSelected)
                            end
                        end
                    })
                    RageUI.Button("Retirer de l'Argent Sale", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            local amount = KeyboardInput("Montant", "", 10)
                            if amount ~= nil then
                                TriggerServerEvent('yazho:removeBlackMoneyFromCasier2', tonumber(amount), identifierSelected)
                                Citizen.Wait(500)
                                getAllContentCasierNotOwner(identifierSelected)
                            end
                        end
                    })
                    RageUI.Line()
                    RageUI.Separator("Gestion d'Objets")
                    RageUI.Button("Déposer Objet(s)", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            menuDepoItems2()
                        end
                    })
                    RageUI.Button("Retirer Objet(s)", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            menuRetraitItems2()
                        end
                    })
                    RageUI.Line()
                    RageUI.Separator("Gestion d'Armes (SI ARMES PAS = OBJETS)")
                    RageUI.Button("Déposer Arme(s)", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            menuDepoWeapons2()
                        end
                    })
                    RageUI.Button("Retirer Arme(s)", nil, {RightLabel = "→→"}, true, {
                        onSelected = function()
                            menuRetraitWeapons2()
                        end
                    })
                    end, function()
                end)
            if not RageUI.Visible(ckr) and not RageUI.Visible(moncasier) and not RageUI.Visible(moncasiersub) and not RageUI.Visible(moncasiersub2) then
            ckr = RMenu:DeleteType("ckr", true)
		end
	end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermVestiaire then
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.vestiaire.position.x, Config.pos.vestiaire.position.y, Config.pos.vestiaire.position.z)
        if dist3 <= 15 then
            Timer = 0
			DrawMarker(23, Config.pos.vestiaire.position.x, Config.pos.vestiaire.position.y, Config.pos.vestiaire.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
		end
        if dist3 <= 2.0 then
            Timer = 0   
                ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder au Vestiaire.")
                    if IsControlJustPressed(1,51) then
                        getAllCasier()
                        CloackRoomPolice()
                    end   
                end
            end 
        Citizen.Wait(Timer)
    end
end)

function ApplySkin(infos)
	TriggerEvent('skinchanger:getSkin', function(skin)
		local uniformObject
		if skin.sex == 0 then
			uniformObject = infos.variations.male
		else
			uniformObject = infos.variations.female
		end
		if uniformObject then
			TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
		end
		infos.onEquip()
	end)
end

function getAllCasier()
    ESX.TriggerServerCallback('yazho:getAllCasier', function(all)
        allCasier = all
    end)
end

function getAllContentCasier()
    ESX.TriggerServerCallback('yazho:getAllContentCasier', function(all)
        allContentCasier = all
    end)
    ESX.TriggerServerCallback('yazho:getAllWeaponInCasier', function(weapons)
        allWeaponInCasier = weapons
    end)
    ESX.TriggerServerCallback('yazho:getAllItemsInCasier', function(items)
        allItemsInCasier = items
    end)
end

function getAllContentCasierNotOwner(identifier)
    ESX.TriggerServerCallback('yazho:getAllContentCasier2', function(all)
        allContentCasier2 = all
    end, identifier)
    ESX.TriggerServerCallback('yazho:getAllWeaponInCasier2', function(weapons)
        allWeaponInCasier2 = weapons
    end, identifier)
    ESX.TriggerServerCallback('yazho:getAllItemsInCasier2', function(items)
        allItemsInCasier2 = items
    end, identifier)
end

function menuDepoItems()
    local StockPlayer = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockPlayer:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    ESX.TriggerServerCallback('yazhopolice:getPlayerInventory', function(inventory)
        RageUI.Visible(StockPlayer, not RageUI.Visible(StockPlayer))
    while StockPlayer do
        Citizen.Wait(0)
            RageUI.IsVisible(StockPlayer, true, true, true, function()
                for i=1, #inventory.items, 1 do
                    if inventory ~= nil then
                         local item = inventory.items[i]
                            if item.count > 0 then
                                    RageUI.Button(item.label, nil, {RightLabel = item.count}, true, {
                                        onSelected = function()
                                            local count = KeyboardInput("Entrez un valeur.", '' , 8)
                                            TriggerServerEvent('yazho:addItemToCasier', item.name, tonumber(count))
                                            RageUI.CloseAll()
                                        end
                                    })
                                end
                            else
                                RageUI.Separator('Chargement en cours')
                            end
                        end
                    end, function()
                    end)
                if not RageUI.Visible(StockPlayer) then
                StockPlayer = RMenu:DeleteType("Casier", true)
            end
        end
    end)
end

function menuRetraitItems()
    local StockCasier = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockCasier:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(StockCasier, not RageUI.Visible(StockCasier))
        while StockCasier do
            Citizen.Wait(0)
                RageUI.IsVisible(StockCasier, true, true, true, function()
                        for k,v in pairs(allItemsInCasier) do 
                            if v.amount > 0 then
                            RageUI.Button(v.label, nil, {RightLabel = v.amount}, true, {
                                onSelected = function()
                                    local count = KeyboardInput("Combien ?", "", 2)
                                    TriggerServerEvent('yazho:removeItemFromCasier', v.name, tonumber(count))
                                    RageUI.CloseAll()
                                end
                            })
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(StockCasier) then
            StockCasier = RMenu:DeleteType("Casier", true)
        end
    end
end

function menuDepoWeapons()
    local StockPlayerWeapon = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockPlayerWeapon:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
        RageUI.Visible(StockPlayerWeapon, not RageUI.Visible(StockPlayerWeapon))
    while StockPlayerWeapon do
        Citizen.Wait(0)
            RageUI.IsVisible(StockPlayerWeapon, true, true, true, function()
                local weaponList = ESX.GetWeaponList()
                for i=1, #weaponList, 1 do
                    local weaponHash = GetHashKey(weaponList[i].name)
                    if HasPedGotWeapon(PlayerPedId(), weaponHash, false) and weaponList[i].name ~= 'WEAPON_UNARMED' then
                    RageUI.Button(weaponList[i].label, nil, {RightLabel = ""}, true, {
                        onSelected = function()
                            TriggerServerEvent('yazho:addWeaponToCasier', weaponList[i].name, 1)
                            RageUI.CloseAll()
                        end
                    })
                end
            end
        end, function()
        end)
        if not RageUI.Visible(StockPlayerWeapon) then
            StockPlayerWeapon = RMenu:DeleteType("Casier", true)
        end
    end
end

function menuRetraitWeapons()
    local StockWeaponCasier = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockWeaponCasier:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(StockWeaponCasier, not RageUI.Visible(StockWeaponCasier))
        while StockWeaponCasier do
            Citizen.Wait(0)
                RageUI.IsVisible(StockWeaponCasier, true, true, true, function()
                        for k,v in pairs(allWeaponInCasier) do 
                            if v.amount > 0 then
                            RageUI.Button(v.label, nil, {RightLabel = v.amount}, true, {
                                onSelected = function()
                                    local count = KeyboardInput("Combien ?", "", 2)
                                    TriggerServerEvent('yazho:removeWeaponFromCasier', v.name, tonumber(count))
                                    RageUI.CloseAll()
                                end
                            })
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(StockWeaponCasier) then
            StockWeaponCasier = RMenu:DeleteType("Casier", true)
        end
    end
end

function menuDepoItems2()
    local StockPlayer = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockPlayer:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    ESX.TriggerServerCallback('yazhopolice:getPlayerInventory', function(inventory)
    RageUI.Visible(StockPlayer, not RageUI.Visible(StockPlayer))
        while StockPlayer do
            Citizen.Wait(0)
                RageUI.IsVisible(StockPlayer, true, true, true, function()
                    for i=1, #inventory.items, 1 do
                        if inventory ~= nil then
                            local item = inventory.items[i]
                                if item.count > 0 then
                                        RageUI.Button(item.label, nil, {RightLabel = item.count}, true, {
                                            onSelected = function()
                                                local count = KeyboardInput("Combien ?", '' , 8)
                                                TriggerServerEvent('yazho:addItemToCasier2', item.name, tonumber(count), identifierSelected)
                                                RageUI.CloseAll()
                                            end
                                        })
                                    end
                                else
                                    RageUI.Separator('Chargement en cours')
                                end
                            end
                        end, function()
                        end)
                    if not RageUI.Visible(StockPlayer) then
                    StockPlayer = RMenu:DeleteType("Casier", true)
                end
            end
        end)
    end

function menuRetraitItems2()
    local StockCasier = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockCasier:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(StockCasier, not RageUI.Visible(StockCasier))
        while StockCasier do
            Citizen.Wait(0)
                RageUI.IsVisible(StockCasier, true, true, true, function()
                        for k,v in pairs(allItemsInCasier) do 
                            if v.amount > 0 then
                            RageUI.Button(v.label, nil, {RightLabel = v.amount}, true, {
                                onSelected = function()
                                    local count = KeyboardInput("Combien ?", "", 2)
                                    TriggerServerEvent('yazho:removeItemFromCasier2', v.name, tonumber(count), identifierSelected)
                                    RageUI.CloseAll()
                                end
                            })
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(StockCasier) then
            StockCasier = RMenu:DeleteType("Casier", true)
        end
    end
end

function menuDepoWeapons2()
    local StockPlayerWeapon = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockPlayerWeapon:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(StockPlayerWeapon, not RageUI.Visible(StockPlayerWeapon))
    while StockPlayerWeapon do
        Citizen.Wait(0)
            RageUI.IsVisible(StockPlayerWeapon, true, true, true, function()  
                local weaponList = ESX.GetWeaponList()
                for i=1, #weaponList, 1 do
                    local weaponHash = GetHashKey(weaponList[i].name)
                    if HasPedGotWeapon(PlayerPedId(), weaponHash, false) and weaponList[i].name ~= 'WEAPON_UNARMED' then
                    RageUI.Button(weaponList[i].label, nil, {RightLabel = ""}, true, {
                        onSelected = function()
                            TriggerServerEvent('yazho:addWeaponToCasier2', weaponList[i].name, 1, identifierSelected)
                            RageUI.CloseAll()
                        end
                    })
                 end
            end
        end, function()
        end)
        if not RageUI.Visible(StockPlayerWeapon) then
            StockPlayerWeapon = RMenu:DeleteType("Casier", true)
        end
    end
end

function menuRetraitWeapons2()
    local StockWeaponCasier = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    StockWeaponCasier:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(StockWeaponCasier, not RageUI.Visible(StockWeaponCasier))
        while StockWeaponCasier do
            Citizen.Wait(0)
                RageUI.IsVisible(StockWeaponCasier, true, true, true, function()
                        for k,v in pairs(allWeaponInCasier2) do 
                            if v.amount > 0 then
                            RageUI.Button(v.label, nil, {RightLabel = v.amount}, true, {
                                onSelected = function()
                                    local count = KeyboardInput("Combien ?", "", 2)
                                    TriggerServerEvent('yazho:removeWeaponFromCasier2', v.name, tonumber(count), identifierSelected)
                                    RageUI.CloseAll()
                                end
                            })
                        end
                    end
                end, function()
                end)
            if not RageUI.Visible(StockWeaponCasier) then
            StockWeaponCasier = RMenu:DeleteType("Casier", true)
        end
    end
end