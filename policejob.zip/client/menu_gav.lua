ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

function DrawTenueImage(textureDict, textureName)
    local screenWidth, screenHeight = GetScreenResolution()
    local x = 0.27
    local y = 0.105
    local width = (100 / screenWidth)
    local height = (150 / screenHeight)
    if not HasStreamedTextureDictLoaded(textureDict) then
        RequestStreamedTextureDict(textureDict, true)
        while not HasStreamedTextureDictLoaded(textureDict) do
            Wait(0)
        end
    end
    DrawSprite(textureDict, textureName, x, y, width, height, 0.0, 255, 255, 255, 255)
end

function TenueGAV()
    local gav = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
	gav:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(gav, not RageUI.Visible(gav))
    while gav do
        Citizen.Wait(0)
            RageUI.IsVisible(gav, true, true, true, function()
                RageUI.Button("Reprendre Sa Tenue", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                            TriggerEvent('skinchanger:loadSkin', skin)
                            ESX.ShowNotification("Tenue Quotidienne reprise.")
                        end)
                    end
                })
                RageUI.Line()
                RageUI.Separator("Action(s) de G.A.V.")

                RageUI.Button("Mettre la Tenue Demandée", nil, {RightLabel = "→"}, true, {
                    onActive = function()
                        DrawTenueImage("vehicle_images", "tenue")
                    end,
                    onSelected = function() 
                        SetPedComponentVariation(GetPlayerPed(-1) , 8, 15, 0)
                        SetPedComponentVariation(GetPlayerPed(-1) , 11, 146, 0)
                        SetPedComponentVariation(GetPlayerPed(-1) , 10, 0, 0)
                        SetPedComponentVariation(GetPlayerPed(-1) , 4, 3, 7)
                        ESX.ShowNotification("Tenue changée.")
                    end
                })      
        end, function()
    end)
    if not RageUI.Visible(gav) then
        gav = RMenu:DeleteType("gav", true)
    end
end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.tenueGav.position.x, Config.pos.tenueGav.position.y, Config.pos.tenueGav.position.z)
        if dist3 <= 15 then 
            Timer = 0
            DrawMarker(23, Config.pos.tenueGav.position.x, Config.pos.tenueGav.position.y, Config.pos.tenueGav.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
        end
        if dist3 <= 2.0 then 
            Timer = 0
            ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder au Vestiaire G.A.V.")
            if IsControlJustPressed(1, 51) then
                TenueGAV()
            end   
        end
        Citizen.Wait(Timer)
    end
end)
