ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)


function bddLSPD(id)
    local main = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    ESX.TriggerServerCallback('yazho:getPlayer', function(data)
    ESX.TriggerServerCallback('esx_billing:getTargetBills', function(allBiling)
    main:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(main, not RageUI.Visible(main))
    while main do
        Citizen.Wait(0)
            RageUI.IsVisible(main, true, true, true, function()
            RageUI.Line()
            RageUI.Separator("Informations Essentielles")
            RageUI.Button("Nom/Prénom - "..data.lastname.." "..data.firstname, nil, {}, true, {})
            RageUI.Button("Date de Naissane - "..data.dateAnniv, nil, {}, true, {})
            RageUI.Button("Proffesion - "..data.job, nil, {}, true, {})
            RageUI.Separator("Grade - "..data.grade)
            RageUI.Line()
            RageUI.Separator("Autres")
            RageUI.Button("Argent Liquide - ~g~"..data.cashMoney.."$", nil, {}, true, {})
            RageUI.Button("Argent Banquaire - ~b~"..data.bankMoney.."$", nil, {}, true, {})

        end, function()
        end)
        if not RageUI.Visible(main) then
            main = RMenu:DeleteType("main", true)
        end
    end
end, id)
end, id)
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermBDD then
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.menuVerifBdd.position.x, Config.pos.menuVerifBdd.position.y, Config.pos.menuVerifBdd.position.z)
        if dist3 <= 15 then
            Timer = 0
            DrawMarker(23, Config.pos.menuVerifBdd.position.x, Config.pos.menuVerifBdd.position.y, Config.pos.menuVerifBdd.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
          end
        if dist3 <= 2.0 then 
                Timer = 0
                        ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder à la Base de Données.")
                        if IsControlJustPressed(1,51) then
                            local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                            if closestPlayer ~= -1 and closestDistance <= 3.0 then
                                bddLSPD(GetPlayerServerId(closestPlayer))
                            else
                                RageUI.Popup({message = "~r~Aucun Joueur à proximité."})
                            end
                    end   
                end
            end 
        Citizen.Wait(Timer)
    end
end)