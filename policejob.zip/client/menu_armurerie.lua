ESX = nil
local stockAmmu = {}

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end

    ESX.PlayerData = ESX.GetPlayerData()
end)

function KeyboardInput(entryTitle, defaultText, maxLength)
    AddTextEntry("FMMC_KEY_TIP1", entryTitle)
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", defaultText, "", "", "", maxLength)
    while UpdateOnscreenKeyboard() == 0 do
        Citizen.Wait(0)
    end
    if GetOnscreenKeyboardResult() then
        return GetOnscreenKeyboardResult()
    end
    return nil
end

function ArmuLSPD()
    local armu = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    armu:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(armu, not RageUI.Visible(armu))
    while armu do
        Citizen.Wait(0)
            RageUI.IsVisible(armu, true, true, true, function()
            if Config.armesEnItems then
                RageUI.Button("Rendre votre Équipement", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        TriggerServerEvent('rmvarmurerie', "weapon_pistol", 1)
                        TriggerServerEvent('rmvarmurerie', "weapon_pumpshotgun_mk2", 1)
                        TriggerServerEvent('rmvarmurerie', "weapon_carbinerifle", 1)
                        TriggerServerEvent('rmvarmurerie', "WEAPON_NIGHTSTICK", 1)
                        TriggerServerEvent('rmvarmurerie', "WEAPON_STUNGUN", 1)
                        TriggerServerEvent('rmvarmurerie', "WEAPON_FLASHLIGHT", 1)
                    end
                })
                RageUI.Line()
                RageUI.Button("Equipement de base", nil, {RightLabel = "→"}, true, {
                    onSelected = function() 
                        TriggerServerEvent('equipementbase')
                    end
                })
                RageUI.Separator("Armes(s) Disponible(s)")
                for k,v in pairs(Config.armurerie) do
                    if ESX.PlayerData.job.grade >= v.minimum_grade then
                    RageUI.Button(v.nom.." ~m~("..v.arme..")~s~", nil, {RightLabel = "→"}, true, {
                        onSelected = function()
                            TriggerServerEvent('armurerie', v.arme, 1)
                        end
                    })
                end
            end
            else
                RageUI.Button("Rendre votre Équipement", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        KeyboardInput("Attention", "Cette action supprime toutes vos armes présentes sur vous.", 40)
                        local input = KeyboardInput("Confirmez en tapant 'OUI'", "", 3) 
                        if input and string.lower(input) == "oui" then
                            local playerId = GetPlayerServerId(PlayerId())
                            TriggerServerEvent("clearPlayerLoadout", playerId)
                            ESX.ShowNotification("Votre équipement a été rendu avec succès.")
                        else
                            ESX.ShowNotification("~r~Action annulée.")
                        end
                    end
                })
                RageUI.Line()
                RageUI.Button("Equipement de base", nil, {RightLabel = "→"}, true, {
                    onSelected = function() 
                        TriggerServerEvent('equipementbase')
                    end
                })
                RageUI.Separator("Armes(s) Disponible(s)")
                for k,v in pairs(Config.armurerie) do
                    if ESX.PlayerData.job.grade >= v.minimum_grade then
                        RageUI.Button(v.nom.." ~m~("..v.arme..")~s~", nil, {RightLabel = "→"}, true, {
                            onSelected = function()
                                TriggerServerEvent('yazho:addWeapon', v.arme, 99999)
                            end
                        })
                        
                    end
                end
            end
        end, function()
        end)
        if not RageUI.Visible(armu) then
            armu = RMenu:DeleteType("armu", true)
        end
    end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermAmu then
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.armurerie.position.x, Config.pos.armurerie.position.y, Config.pos.armurerie.position.z)
        if dist3 <= 15 then
            Timer = 0
            DrawMarker(23, Config.pos.armurerie.position.x, Config.pos.armurerie.position.y, Config.pos.armurerie.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
        end
        if dist3 <= 2.0 then 
                Timer = 0
				  ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder à l'Armurerie.")
                    if IsControlJustPressed(1,51) then

                        if Config.armesEnItems then
                            for k,v in pairs(Config.armurerie) do
                                ESX.TriggerServerCallback('yazho:getWeaponAmmu', function(amount)
                                        stockAmmu[(v.arme)] = amount
                                        ArmuLSPD()
                                end, (v.arme))
                            end
                        else
                        for k,v in pairs(Config.armurerie) do
                            ESX.TriggerServerCallback('yazho:getWeaponAmmu', function(amount)
                                    stockAmmu[GetHashKey(v.arme)] = amount
                                    ArmuLSPD()
                            end, GetHashKey(v.arme))
                        end
                    end
                    end   
                end
            end 
        Citizen.Wait(Timer)
    end
end)