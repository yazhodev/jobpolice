ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

function DrawVehicleImage(textureDict, textureName)
    local screenWidth, screenHeight = GetScreenResolution()
    local x = 0.34
    local y = 0.095
    local width = (270 / screenWidth)
    local height = (135 / screenHeight)
    if not HasStreamedTextureDictLoaded(textureDict) then
        RequestStreamedTextureDict(textureDict, true)
        while not HasStreamedTextureDictLoaded(textureDict) do
            Wait(0)
        end
    end
    DrawSprite(textureDict, textureName, x, y, width, height, 0.0, 255, 255, 255, 255)
end

local FirstName = nil
local LastName = nil
local Subject = nil
local Desc = nil
local tel = nil
local cansend = false

function ServicePolice()
    local accueil = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
	local plainte = RageUI.CreateSubMenu(accueil, "POLICE", "MENU D'INTERACTIONS")
	accueil:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	plainte:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(accueil, not RageUI.Visible(accueil))
    while accueil do
        Citizen.Wait(0)
            RageUI.IsVisible(accueil, true, true, true, function()
                RageUI.Separator("Actions Disponibles")
                RageUI.Line()
                RageUI.Button("Demander un Agent", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        TriggerServerEvent("genius:sendcall") 
                        RageUI.Popup({message = "Votre appel a bien été pris en compte."})
                    end
                })
                RageUI.Button("Porter Plainte", nil, {RightLabel = "→"}, true, {}, plainte)
        end, function()
        end)

local function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end    
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end

RageUI.IsVisible(plainte, true, true, true, function()
    RageUI.Separator("Vos Informations")
    RageUI.Button("Entrez votre Nom", nil, {RightLabel = LastName ~= nil and LastName ~= "" and LastName or "AUCUN"}, true, {
        onSelected = function()
            LastName = KeyboardInput("Votre Nom:", nil, 20)
        end
    })  
    RageUI.Button("Entrez votre Prénom", nil, {RightLabel = FirstName ~= nil and FirstName ~= "" and FirstName or "AUCUN"}, true, {
        onSelected = function()
            FirstName = KeyboardInput("Votre Prénom:",nil,20)
        end
    })
    RageUI.Button("Entrez votre Numéro", nil, {RightLabel = tel ~= nil and tel ~= "" and tel or "AUCUN"}, true, {
        onSelected = function()
            tel = KeyboardInput("Votre Numéro :",nil,350)
        end
    }) 
    RageUI.Line()
    RageUI.Separator("Votre Plainte")
    RageUI.Button("Sujet", nil, {RightLabel = Subject ~= nil and Subject ~= "" and Subject or "AUCUN"}, true, {
        onSelected = function()
            Subject = KeyboardInput("Votre Sujet:",nil,30)
        end
    })
    RageUI.Button("Description de la Plainte", nil, {RightLabel = Desc ~= nil and Desc ~= "" and Desc or "AUCUN"}, true, {
        onSelected = function()
            Desc = KeyboardInput("Votre Description:",nil,350)
        end
    })
	if LastName ~= nil and LastName ~= "" and FirstName ~= nil and FirstName ~= "" and tel ~= nil and tel ~= "" and Subject ~= nil and Subject ~= "" and Desc ~= nil and Desc ~= "" then
		cansend = true
	end
    RageUI.Button("~g~Envoyer", nil, {RightLabel = "→"}, true, {
        onSelected = function() 
            RageUI.CloseAll()
            TriggerServerEvent("genius:sendplainte", LastName, FirstName,tel ,Subject, Desc)
            RageUI.Popup({message = "Votre plainte a bien été pris en compte."})
            FirstName = nil
            LastName = nil
            Subject = nil
            Desc = nil
            tel = nil
        end
    })
	end, function()
	end)
        if not RageUI.Visible(accueil) and not RageUI.Visible(plainte) then
            accueil = RMenu:DeleteType("accueil", true)
        end
    end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.plainterdv.position.x, Config.pos.plainterdv.position.y, Config.pos.plainterdv.position.z)
		if dist3 <= 5.0 then 
			Timer = 0
		DrawMarker(23, Config.pos.plainterdv.position.x, Config.pos.plainterdv.position.y, Config.pos.plainterdv.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
		end
		if dist3 <= 3.0 then 
                Timer = 0
                ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder à l'Accueil.")
                        if IsControlJustPressed(1,51) then
                            ServicePolice()
                    end   
                end
        Citizen.Wait(Timer)
    end
end)