ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end

    ESX.PlayerData = ESX.GetPlayerData()
end)

function DrawTenueImage(textureDict, textureName)
    local screenWidth, screenHeight = GetScreenResolution()
    local x = 0.34
    local y = 0.095
    local width = (270 / screenWidth)
    local height = (135 / screenHeight)

    if not HasStreamedTextureDictLoaded(textureDict) then
        RequestStreamedTextureDict(textureDict, true)
        while not HasStreamedTextureDictLoaded(textureDict) do
            Wait(0)
        end
    end
    DrawSprite(textureDict, textureName, x, y, width, height, 0.0, 255, 255, 255, 255)
end

function VehiculesLSPD()
    local garagemenu = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    garagemenu:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(garagemenu, not RageUI.Visible(garagemenu))
    while garagemenu do
        Citizen.Wait(0)
            RageUI.IsVisible(garagemenu, true, true, true, function()
                for k,v in pairs(police.vehicles.car) do
                    if v.category ~= nil then 
                        RageUI.Separator(v.category)
                        RageUI.Line()
                    else
                        RageUI.Button(v.label.." ~m~("..v.model..")", "(Diponible en Fonction du Grade).", {RightLabel = "→"}, ESX.PlayerData.job.grade >= v.minimum_grade, {
                            onActive = function()
                                DrawVehicleImage("vehicle_images", v.model)
                            end,
                            onSelected = function()
                            local playerPed = PlayerPedId()
                            local spawnCoords = vector3(447.2351, -986.578, 25.336)
                            local spawnHeading = 179.77772521973           
                            RequestModel(v.model)
                            while not HasModelLoaded(v.model) do
                                Wait(0) 
                            end
                            local vehicle = CreateVehicle(v.model, spawnCoords.x, spawnCoords.y, spawnCoords.z, spawnHeading, true, false)
                            TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
                            SetVehicleDirtLevel(vehicle, 0.0)
                            ESX.ShowNotification("Véhicule mis à disposition.")
                            RageUI.CloseAll()
                            end
                        })
                    end
                end
			end, function()    
			end)

		if not RageUI.Visible(garagemenu) then
			garagemenu = RMenu:DeleteType("garagemenu", true)
		end
	end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        if Config.GarageCar == true then
        if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermGarage then
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.garagevoiture.position.x, Config.pos.garagevoiture.position.y, Config.pos.garagevoiture.position.z)
        if dist3 <= 15 then
            Timer = 0
            DrawMarker(23, Config.pos.garagevoiture.position.x, Config.pos.garagevoiture.position.y, Config.pos.garagevoiture.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
          end
        if dist3 <= 2.0 then 
                Timer = 0
                    ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder au Garage de Véhicules.")
                        if IsControlJustPressed(1,51) then
                            for k,v in pairs(police.vehicles.car) do
                            if v.category == nil then
                                ESX.TriggerServerCallback('yazho:getVehGarage', function(amount)
                                        VehiculesLSPD()
                                end, GetHashKey(v.model))
                            end
                        end
                    end   
                end
            end 
        end
        Citizen.Wait(Timer)
    end
end)

function SpawnVoiture(car)
    local carHash = GetHashKey(car)
    RequestModel(carHash)
    while not HasModelLoaded(carHash) do
        Citizen.Wait(0)
    end
    local playerPed = GetPlayerPed(-1)
    local x, y, z = table.unpack(GetEntityCoords(playerPed, false))
    local vehicle = CreateVehicle(carHash, Config.spawn.spawnvoiture.position.x, Config.spawn.spawnvoiture.position.y, Config.spawn.spawnvoiture.position.z, Config.spawn.spawnvoiture.position.h, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    SetPedIntoVehicle(playerPed, vehicle, -1)
    SetVehicleMaxMods(vehicle)
end

function HelicoLSPD()
	local garagemenuh = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    garagemenuh:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
		RageUI.Visible(garagemenuh, not RageUI.Visible(garagemenuh))
			while garagemenuh do
    			Citizen.Wait(0)
        			RageUI.IsVisible(garagemenuh, true, true, true, function()
                        RageUI.Button("Ranger votre Véhicule", nil, {RightLabel = "→"}, true, {
                            onSelected = function()
                                local playerPed = PlayerPedId()
                                local vehicle = GetVehiclePedIsIn(playerPed, false)
                                
                                if vehicle ~= 0 then
                                    DeleteEntity(vehicle)
                                    ESX.ShowNotification("Véhicule rangé avec succès.")
                                else
                                    ESX.ShowNotification("~r~Vous n'êtes pas dans un véhicule.")
                                end
                            end
                        })
                        RageUI.Line()
                        
                        for k,v in pairs(police.vehicles.helico) do
                            if v.category ~= nil then 
                                RageUI.Separator(v.category)
                            else
                                RageUI.Button(v.label.." ~m~("..v.model..")", "(Diponible en Fonction du Grade).", {RightLabel = "→"}, ESX.PlayerData.job.grade >= v.minimum_grade, {
                                    onActive = function()
                                        DrawTenueImage("vehicle_images", v.model)
                                    end,
                                    onSelected = function()
                                    local playerPed = PlayerPedId()
                                    local playerCoords = GetEntityCoords(playerPed)            
                                    RequestModel(v.model)
                                    while not HasModelLoaded(v.model) do
                                        Wait(0) 
                                    end
                                    local vehicle = CreateVehicle(v.model, playerCoords.x, playerCoords.y, playerCoords.z, true, false)
                                    TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
                                    SetVehicleDirtLevel(vehicle, 0.0)
                                    ESX.ShowNotification("Véhicule mis à disposition.")
                                    end
                                })
                            end
                        end
                    end, function()    
                    end)
   
		if not RageUI.Visible(garagemenuh) then
			garagemenuh = RMenu:DeleteType("garagemenuh", true)
		end
	end
end
      


Citizen.CreateThread(function()
while true do
    local Timer = 800
    if Config.GarageHeli == true then
    if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermGarageHeli then
    local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
    local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.garageheli.position.x, Config.pos.garageheli.position.y, Config.pos.garageheli.position.z)
    if dist3 <= 15 then
        Timer = 0
        DrawMarker(23, Config.pos.garageheli.position.x, Config.pos.garageheli.position.y, Config.pos.garageheli.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
      end    
    if dist3 <= 2.0 then 
            Timer = 0
            ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder au Garage d'Hélicoptères.")
                    if IsControlJustPressed(1,51) then
                        for k,v in pairs(police.vehicles.helico) do
                            if v.category == nil then
                                ESX.TriggerServerCallback('yazho:getVehGarage', function(amount)
                                    HelicoLSPD()
                                end, GetHashKey(v.model))
                            end
                        end
                    end   
                end
            end
        end 
        Citizen.Wait(Timer)
    end
end)

function SpawnHelico(car)
    local car = GetHashKey(car)
    RequestModel(car)
    while not HasModelLoaded(car) do
        RequestModel(car)
        Citizen.Wait(0)
    end
    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
    local vehicle = CreateVehicle(car, Config.spawn.spawnheli.position.x, Config.spawn.spawnheli.position.y, Config.spawn.spawnheli.position.z, Config.spawn.spawnheli.position.h, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    local plaque = "LSPD"..math.random(1,15)
    SetVehicleNumberPlateText(vehicle, plaque)
    SetPedIntoVehicle(GetPlayerPed(-1),vehicle,-1)
    SetVehicleMaxMods(vehicle)
end

function BateauLSPD()
    local garagemenub = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    garagemenub:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(garagemenub, not RageUI.Visible(garagemenub))
    while garagemenub do
        Citizen.Wait(0)
            RageUI.IsVisible(garagemenub, true, true, true, function()

                RageUI.Button("Ranger votre Véhicule", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        local playerPed = PlayerPedId()
                        local vehicle = GetVehiclePedIsIn(playerPed, false)
                        if vehicle ~= 0 then
                            DeleteEntity(vehicle)
                            local destination = vector3(-800.544, -1494.72, 1.5952)
                            SetEntityCoords(playerPed, destination.x, destination.y, destination.z, false, false, false, false)
                
                            ESX.ShowNotification("Véhicule rangé avec succès.")
                        else
                            ESX.ShowNotification("~r~Vous n'êtes pas dans un véhicule.")
                        end
                    end
                })
                
                RageUI.Line()
                
            for k,v in pairs(police.vehicles.bateaux) do
                if v.category ~= nil then 
                    RageUI.Separator(v.category)
                else
                    RageUI.Button(v.label.." ~m~("..v.model..")", "(Diponible en Fonction du Grade).", {RightLabel = "→"}, ESX.PlayerData.job.grade >= v.minimum_grade, {
                        onActive = function()
                            DrawVehicleImage("vehicle_images", v.model)
                        end,
                        onSelected = function()
                            local playerPed = PlayerPedId()
                            local spawnCoords = vector3(-798.648, -1500.65, 0.5989)
                            local spawnHeading = 111.46364593506            
                            RequestModel(v.model)
                            while not HasModelLoaded(v.model) do
                                Wait(0) 
                            end
                            local vehicle = CreateVehicle(v.model, spawnCoords.x, spawnCoords.y, spawnCoords.z, spawnHeading, true, false)
                        TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
                        SetVehicleDirtLevel(vehicle, 0.0)
                        ESX.ShowNotification("Véhicule mis à disposition.")
                        end
                    })
                end
            end

            end, function()    
            end)
        if not RageUI.Visible(garagemenub) then
            garagemenub = RMenu:DeleteType("garagemenub", true)
        end
    end
end

Citizen.CreateThread(function()
    while true do
    local Timer = 800
    if Config.GarageBateau == true then
    if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermGarageBateau then
    local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
    local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.garagebateau.position.x, Config.pos.garagebateau.position.y, Config.pos.garagebateau.position.z)
    if dist3 <= 15 then
        Timer = 0
        DrawMarker(23, Config.pos.garagebateau.position.x, Config.pos.garagebateau.position.y, Config.pos.garagebateau.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
        end        
    if dist3 <= 7.0 then 
            Timer = 0
                ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder au Garage de Bateau(x).")
                    if IsControlJustPressed(1,51) then
                        for k,v in pairs(police.vehicles.bateaux) do
                            if v.category == nil then
                                ESX.TriggerServerCallback('yazho:getVehGarage', function(amount)
                                    BateauLSPD()
                                end, GetHashKey(v.model))
                            end
                        end
                    end
                end   
            end
        end 
        Citizen.Wait(Timer)
    end
end)

function SpawnBato(car)
    local car = GetHashKey(car)
    RequestModel(car)
    while not HasModelLoaded(car) do
        RequestModel(car)
        Citizen.Wait(0)
    end
    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
    local vehicle = CreateVehicle(car, Config.spawn.spawnbato.position.x, Config.spawn.spawnbato.position.y, Config.spawn.spawnbato.position.z, Config.spawn.spawnbato.position.h, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    local plaque = "LSPD"..math.random(1,15)
    SetVehicleNumberPlateText(vehicle, plaque)
    SetPedIntoVehicle(GetPlayerPed(-1),vehicle,-1) 
    SetVehicleMaxMods(vehicle)
end

function ExtraPolice()
    local mainextra = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    mainextra:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)

    RageUI.Visible(mainextra, not RageUI.Visible(mainextra))
    while mainextra do
        Citizen.Wait(0)
            RageUI.IsVisible(mainextra, true, true, true, function()
                RageUI.Button("Ranger votre Véhicule", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        local playerPed = PlayerPedId()
                        local vehicle = GetVehiclePedIsIn(playerPed, false)
                        
                        if vehicle ~= 0 then
                            DeleteEntity(vehicle)
                            ESX.ShowNotification("Véhicule rangé avec succès.")
                        else
                            ESX.ShowNotification("~r~Vous n'êtes pas dans un véhicule.")
                        end
                    end
                })
                RageUI.Line()
                RageUI.Separator("Action(s) Disponible(s)")
                RageUI.Button("Nettoyer le véhicule", nil, {RightLabel = "→"}, true, {
                    onSelected = function()
                        local vehicle = GetVehiclePedIsIn(PlayerPedId(), true)
                        SetVehicleDirtLevel(vehicle, 0)
                        RageUI.Popup({message = "Véhicule néttoyé avec succès."})
                    end
                })
            end, function()
            end)

        if not RageUI.Visible(mainextra) then
            mainextra = RMenu:DeleteType(mainextra, true)
        end
    end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        if Config.GarageCar == true then
            if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermRmvCar then
                local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
                local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.modifcar.position.x, Config.pos.modifcar.position.y, Config.pos.modifcar.position.z)
                if dist3 <= 15 then
                    Timer = 0
                    DrawMarker(36, Config.pos.modifcar.position.x, Config.pos.modifcar.position.y, Config.pos.modifcar.position.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0 , 255, 0, 0, 255, false, true, 2, nil, nil, false)
                end        
                if dist3 <= 5.0 then 
                    Timer = 0
                    if IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                        ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder au(x) Fonction(s) du Garage.")
                        if IsControlJustPressed(1, 51) then
                            ExtraPolice()
                        end
                    else
                        ESX.ShowHelpNotification("Vous devez être dans un véhicule pour accéder au Garage.")
                    end
                end
            end 
        end
        Citizen.Wait(Timer)
    end
end)

function SetVehicleMaxMods(vehicle)
    local props = {
      modEngine       = 2,
      modBrakes       = 2,
      modTransmission = 2,
      modSuspension   = 3,
      modTurbo        = true,
    }
    ESX.Game.SetVehicleProperties(vehicle, props)
end