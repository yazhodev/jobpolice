ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)

local cam = false

function CameraMenu()
    local camera = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
    camera:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
    RageUI.Visible(camera, not RageUI.Visible(camera))
    while camera do
        Citizen.Wait(0)
            RageUI.IsVisible(camera, true, true, true, function()
                if cam then 
                    RageUI.Button("~r~Retour", nil, {RightLabel = "→"}, true, {
                        onSelected = function()   
                            TriggerEvent('cctv:camera', 0)
                            cam = false
                            cooldowncool(2000)
                        end
                    })
                else
                RageUI.Separator("Liste des Caméras Disponibles")
                RageUI.Line()
                RageUI.Button("Caméra n°1 ~m~(Ballas)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 25)
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°2 ~m~(Families)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 26) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°3 ~m~(Vagos)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 27) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°4 ~m~( Bijouterie )~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 22) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°5 ~m~(Paleto Bank Outside)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 23) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°6 ~m~(Main Bank 1)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 24) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°7 ~m~(Superette Unicorn)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 1) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°8 ~m~(Superette Ballas)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 2) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°9 ~m~(Superette Ballas)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 3) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°10 ~m~(Superette BurgerShot)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 4) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°11 ~m~(Superette Taxi)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 5) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°12 ~m~(Superette Vinewood)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 6) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°13 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 7) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°14 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 8) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°15 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 9) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°16 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 10) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°17 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 11) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°18 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 12) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°19 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 13) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°20 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 14) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°21 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 15) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°22 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 16) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°23 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 17) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°24 ~m~(Superette)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 18) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°25 ~m~(Cam Power)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 19) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°26 ~m~(Avant Prison)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 20) 
                        cam = true
                        cooldowncool(2000)
                    end
                })
                RageUI.Button("Caméra n°27 ~m~(Cellule)~s~", nil, {RightLabel = "→→"}, true, {
                    onSelected = function()   
                        TriggerEvent('cctv:camera', 21)
                        cam = true
                        cooldowncool(2000)
                    end
                })
            end
            end, function()
            end)
	
        if not RageUI.Visible(camera) and not RageUI.Visible(plainte) then
            camera = RMenu:DeleteType("camera", true)
        end
    end
end

Citizen.CreateThread(function()
    while true do
        local Timer = 800
        if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermCam then
        local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
        local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.cameraview.position.x, Config.pos.cameraview.position.y, Config.pos.cameraview.position.z)
		if dist3 <= 15 then 
			Timer = 0
            DrawMarker(23, Config.pos.cameraview.position.x, Config.pos.cameraview.position.y, Config.pos.cameraview.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
		end
		if dist3 <= 2.0 then 
                Timer = 0
                ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder aux Vidéos de Surveillance.")
                        if IsControlJustPressed(1,51) then
                        CameraMenu()
                    end   
                end
            end
        Citizen.Wait(Timer)
    end
end)