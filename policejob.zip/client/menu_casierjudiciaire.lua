ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        if Config.ESextendedLegacy == true then
            ESX = exports["es_extended"]:getSharedObject()
        else
            TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)
        end
        Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    ESX.PlayerData = ESX.GetPlayerData()
end)

local current = "police"
local dangerosityTable = {[1] = "Coopératif",[2] = "Dangereux",[3] = "Dangereux et armé",[4] = "Terroriste"}
lspdCJBuilder = {dangerosity = 1}
lspdCJData = nil
lspdCJindex = 0
local filterArray = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" }
local filter = 1

RegisterNetEvent("yazho:cjGet")
AddEventHandler("yazho:cjGet", function(result)
    local found = 0
    for k,v in pairs(result) do
        found = found + 1
    end
    if found > 0 then lspdCJData = result end
end)

function notNilString(str)
    if str == nil then
        return ""
    else
        return str
    end
end

local function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
    AddTextEntry('FMMC_KEY_TIP1', TextEntry)
    blockinput = true
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Wait(0)
    end 
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult()
        Wait(500)
        blockinput = false
        return result
    else
        Wait(500)
        blockinput = false
        return nil
    end
end

local function starts(String, Start)
    return string.sub(String, 1, string.len(Start)) == Start
end

function CasiersLSPD()
	local main = RageUI.CreateMenu("POLICE", "MENU D'INTERACTIONS")
	local info = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	local cj = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
	local ajout = RageUI.CreateSubMenu(main, "POLICE", "MENU D'INTERACTIONS")
    main:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	info:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	cj:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)
	ajout:SetRectangleBanner(Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA)

	  RageUI.Visible(main, not RageUI.Visible(main))
			while main do
				Citizen.Wait(0)
					RageUI.IsVisible(main, true, true, true, function()		
					RageUI.Button("Consulter la base de données", nil, {RightLabel = "→"}, true, {
						onSelected = function()
							lspdCJData = nil
							TriggerServerEvent("yazho:cjGet")
						end
					}, cj)
					RageUI.Line()
					RageUI.Separator("Actions Disponibles")
					RageUI.Button("Ajouter un civil à la base de données", nil, {RightLabel = "→"}, true, {}, ajout)
				end, function()
			  	end)
		
			RageUI.IsVisible(cj, true, true, true, function()
				RageUI.List("Filtre :", filterArray, filter, nil, {}, true, function(_, _, _, i)
                    filter = i
                end)
				if lspdCJData == nil then
					RageUI.Separator("~r~Aucun casier")
				else
					for index,cj in pairs(lspdCJData) do
						if starts(cj.firstname:lower(), filterArray[filter]:lower()) then
							RageUI.Line()
                            RageUI.Button("- "..cj.firstname.." "..cj.lastname, nil, {LeftBadge = RageUI.BadgeStyle.Star, RightLabel = "→→" }, true, {
                                    onSelected = function()
										lspdCJindex = index
                                    end
                                }, info)
						else 
							RageUI.Separator("~r~Aucun casier commençant par "..filterArray[filter])
						end
					end
				end
			end, function()
			end)
		
			RageUI.IsVisible(ajout, true, true, true, function()
				RageUI.Button("Entrez le Nom", nil, {RightLabel = lspdCJBuilder.lastname ~= nil and lspdCJBuilder.lastname ~= "" and lspdCJBuilder.lastname or "AUCUN"}, true, {
					onSelected = function()
						lspdCJBuilder.lastname = KeyboardInput("Nom", "", 10)
					end
				})
				RageUI.Button("Entrez le Prénom", nil, {RightLabel = lspdCJBuilder.firstname ~= nil and lspdCJBuilder.firstname ~= "" and lspdCJBuilder.firstname or "AUCUN"}, true, {
					onSelected = function()
						lspdCJBuilder.firstname = KeyboardInput("Prénom", "", 10)
					end
				})
				RageUI.Button("Entrez le Motif", nil, {RightLabel = lspdCJBuilder.reason ~= nil and lspdCJBuilder.reason ~= "" and lspdCJBuilder.reason or "AUCUN"}, true, {
					onSelected = function()
						lspdCJBuilder.reason = KeyboardInput("Raison", "", 100)
					end
				})
				RageUI.Button("~g~Ajouter", nil, { RightLabel = "→→" }, lspdCJBuilder.firstname ~= nil and lspdCJBuilder.lastname ~= nil and lspdCJBuilder.reason ~= nil, {
					onSelected = function()
						RageUI.GoBack()
						TriggerServerEvent("yazho:cjAdd", lspdCJBuilder)
						RageUI.Popup({ message = "Citoyen(ne) ajouté(e) à la Base de Données." })
					end
				})

			end, function()
			end)
		
			RageUI.IsVisible(info, true, true, true, function()
				if lspdCJData[lspdCJindex] then
					RageUI.Button("Par - "..notNilString(lspdCJData[lspdCJindex].author), nil, {RightLabel = "le "..notNilString(lspdCJData[lspdCJindex].date)}, true, {})
					RageUI.Button("NOM/PRÉNOM", nil, {RightLabel = notNilString(lspdCJData[lspdCJindex].firstname).." "..notNilString(lspdCJData[lspdCJindex].lastname)}, true, {})
					RageUI.Button("Motif(s) - "..notNilString(lspdCJData[lspdCJindex].reason), nil, {}, true, {})
					RageUI.Line()
					RageUI.Separator("Différentes Actions")
					RageUI.Button("~y~Modifier le Motif", nil, {RightLabel = "→"}, true, {
						onSelected = function()
							local newReason = KeyboardInput("Raison", lspdCJData[lspdCJindex].reason..", ", 100)
							if newReason then
								lspdCJBuilder.newreason = newReason
								TriggerServerEvent("yazho:cjModify", lspdCJBuilder, lspdCJindex)
								RageUI.Popup({message = "Raison ajoutée au Casier de l'individu."})
							end
							RageUI.GoBack()
						end
					})
					RageUI.Button("~r~Supprimer le Casier", nil, {RightLabel = "→"}, true, {
						onSelected = function()
							RageUI.GoBack()
							TriggerServerEvent("yazho:cjDel", lspdCJindex)
							RageUI.Popup({message = "Citoyen(ne) retiré(e) de la Base de Données."})
						end
					})
				else
					RageUI.Separator("~r~Aucune information disponible.")
				end
			end)

			  if not RageUI.Visible(main) and not RageUI.Visible(info) and not RageUI.Visible(cj) and not RageUI.Visible(ajout) then
			  main = RMenu:DeleteType("Casier Judiciaire", true)
		  end
	  end
  end   
  
  Citizen.CreateThread(function()
	  while true do
		  local Timer = 800
		  if ESX.PlayerData.job and ESX.PlayerData.job.name == Config.JobName and ESX.PlayerData.job.grade >= Config.PermCasier then
		  local plyCoords3 = GetEntityCoords(GetPlayerPed(-1), false)
		  local dist3 = Vdist(plyCoords3.x, plyCoords3.y, plyCoords3.z, Config.pos.casierjudiciaire.position.x, Config.pos.casierjudiciaire.position.y, Config.pos.casierjudiciaire.position.z)

		  if dist3 <= 15 then
			  Timer = 0
			  DrawMarker(23, Config.pos.casierjudiciaire.position.x, Config.pos.casierjudiciaire.position.y, Config.pos.casierjudiciaire.position.z-0.99, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, Config.ColorMenuR, Config.ColorMenuG, Config.ColorMenuB, Config.ColorMenuA, 0, 1, 2, 1, nil, nil, 0)
			end
			  if dist3 <= 2.0 then
				  Timer = 0   
				  ESX.ShowHelpNotification("Appuyer sur ~INPUT_PICKUP~ pour accéder aux Casiers Judiciaires.")
				  if IsControlJustPressed(1,51) then         
					CasiersLSPD()
					end   
				end
			end
		  Citizen.Wait(Timer)
	end
end)
